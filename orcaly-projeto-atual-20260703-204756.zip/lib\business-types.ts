export type BusinessType =
  | 'services'
  | 'graphic'
  | 'food'
  | 'beauty'
  | 'barber'
  | 'technical_assistance'
  | 'auto'
  | 'store'
  | 'events'
  | 'custom_products'

export type BusinessTypeConfig = {
  id: BusinessType
  label: string
  publicName: string
  siteHeadline: string
  siteSubheadline: string
  siteTitle: string
  siteSubtitle: string
  cta: string
  orderLabel: string
  productLabel: string
  defaultCategories: string[]
  defaultStatuses: string[]
  statuses: string[]
  defaultBenefits: Array<{ titulo: string; texto: string }>
  defaultFaq: Array<{ pergunta: string; resposta: string }>
  defaultFeatures: Array<{ titulo: string; texto: string }>
  features: string[]
  defaultPreviewItems: string[]
}

const aliases: Record<string, BusinessType> = {
  servicos: 'services',
  servicos_gerais: 'services',
  services: 'services',
  outros: 'services',
  consultoria: 'services',
  construcao_reformas: 'services',
  saude_bem_estar: 'services',
  tecnologia: 'services',
  educacao_cursos: 'services',
  fotografia_video: 'services',

  grafica: 'graphic',
  gráfica: 'graphic',
  graphic: 'graphic',

  alimenticio: 'food',
  alimentício: 'food',
  food: 'food',
  restaurante: 'food',
  lanchonete: 'food',

  beleza_estetica: 'beauty',
  estetica: 'beauty',
  estética: 'beauty',
  beauty: 'beauty',

  barbearia: 'barber',
  barber: 'barber',

  assistencia_tecnica: 'technical_assistance',
  assistencia: 'technical_assistance',
  assistência: 'technical_assistance',
  technical_assistance: 'technical_assistance',

  automotivo: 'auto',
  oficina: 'auto',
  auto: 'auto',

  moda_varejo: 'store',
  loja: 'store',
  store: 'store',
  pet_shop: 'store',

  eventos: 'events',
  events: 'events',

  personalizados: 'custom_products',
  custom_products: 'custom_products',
}

const defaultFaq = [
  {
    pergunta: 'Como faço um pedido?',
    resposta: 'Escolha o produto ou serviço, envie seus dados e a empresa continua o atendimento pelo WhatsApp.',
  },
  {
    pergunta: 'Posso alterar informações depois?',
    resposta: 'Sim. Textos, produtos, cores, perguntas e dados da empresa podem ser editados no painel.',
  },
]

const defaultBenefits = [
  { titulo: 'Página profissional', texto: 'Seu negócio ganha uma presença digital organizada para compartilhar.' },
  { titulo: 'Pedidos centralizados', texto: 'Solicitações chegam com dados mais claros para atendimento.' },
  { titulo: 'Atendimento pelo WhatsApp', texto: 'O cliente segue pelo canal que já usa no dia a dia.' },
]

export const businessTypes: BusinessTypeConfig[] = [
  {
    id: 'services',
    label: 'Serviços gerais',
    publicName: 'Orçaly Serviços',
    siteHeadline: 'Receba solicitações e orçamentos com mais organização.',
    siteSubheadline: 'Mostre seus serviços, capture interessados e acompanhe atendimentos pelo painel.',
    siteTitle: 'Receba solicitações e orçamentos com mais organização.',
    siteSubtitle: 'Mostre seus serviços, capture interessados e acompanhe atendimentos pelo painel.',
    cta: 'Solicitar atendimento',
    orderLabel: 'Pedido',
    productLabel: 'Serviço',
    defaultCategories: ['Serviços', 'Pacotes', 'Atendimento', 'Consultoria'],
    defaultStatuses: ['Recebido', 'Em análise', 'Proposta enviada', 'Aprovado', 'Em execução', 'Concluído', 'Cancelado'],
    statuses: ['Recebido', 'Em análise', 'Proposta enviada', 'Aprovado', 'Em execução', 'Concluído', 'Cancelado'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Solicitação de orçamento', texto: 'Receba detalhes do serviço desejado.' },
      { titulo: 'Propostas', texto: 'Organize valores, prazos e condições.' },
      { titulo: 'Status do atendimento', texto: 'Acompanhe cada etapa da solicitação.' },
    ],
    features: ['orcamento', 'propostas', 'clientes', 'status'],
    defaultPreviewItems: ['Instalação', 'Manutenção', 'Consultoria'],
  },
  {
    id: 'graphic',
    label: 'Gráfica e personalizados',
    publicName: 'Orçaly Gráfica',
    siteHeadline: 'Solicite orçamentos com medidas, artes e prazos organizados.',
    siteSubheadline: 'Envie sua ideia, anexe arquivos e acompanhe seu pedido com mais clareza.',
    siteTitle: 'Solicite orçamentos com medidas, artes e prazos organizados.',
    siteSubtitle: 'Envie sua ideia, anexe arquivos e acompanhe seu pedido com mais clareza.',
    cta: 'Pedir orçamento',
    orderLabel: 'Orçamento',
    productLabel: 'Produto',
    defaultCategories: ['Impressos', 'Adesivos', 'Banners', 'Personalizados', 'Comunicação visual'],
    defaultStatuses: ['Recebido', 'Aguardando arte', 'Em análise', 'Proposta enviada', 'Aprovado', 'Em produção', 'Pronto', 'Entregue'],
    statuses: ['Recebido', 'Aguardando arte', 'Em análise', 'Proposta enviada', 'Aprovado', 'Em produção', 'Pronto', 'Entregue'],
    defaultBenefits: [
      { titulo: 'Upload de arte', texto: 'Receba arquivos e referências junto ao orçamento.' },
      { titulo: 'Medidas e quantidades', texto: 'Reduza retrabalho com dados mais completos.' },
      { titulo: 'Produção organizada', texto: 'Acompanhe aprovação, produção e entrega.' },
    ],
    defaultFaq: [
      { pergunta: 'Posso enviar minha arte?', resposta: 'Sim. Você pode enviar a arte ou combinar a criação com a equipe.' },
      { pergunta: 'O orçamento depende da medida?', resposta: 'Sim. Alguns produtos usam largura, altura, acabamento e quantidade.' },
    ],
    defaultFeatures: [
      { titulo: 'Upload de arte', texto: 'Arquivos e referências no pedido.' },
      { titulo: 'Medidas', texto: 'Campos preparados para dimensões.' },
      { titulo: 'Aprovação', texto: 'Fluxo pensado para orçamento e produção.' },
    ],
    features: ['upload_arte', 'medidas', 'producao', 'aprovacao'],
    defaultPreviewItems: ['Cartão de visita', 'Banner', 'Adesivo'],
  },
  {
    id: 'food',
    label: 'Alimentício / Food',
    publicName: 'Orçaly Food',
    siteHeadline: 'Peça online de forma rápida e prática.',
    siteSubheadline: 'Confira nosso cardápio e envie seu pedido pelo WhatsApp.',
    siteTitle: 'Peça online de forma rápida e prática.',
    siteSubtitle: 'Confira nosso cardápio e envie seu pedido pelo WhatsApp.',
    cta: 'Fazer pedido',
    orderLabel: 'Pedido',
    productLabel: 'Item do cardápio',
    defaultCategories: ['Lanches', 'Pizzas', 'Bebidas', 'Sobremesas', 'Combos'],
    defaultStatuses: ['Recebido', 'Em preparo', 'Pronto para retirada', 'Saiu para entrega', 'Entregue', 'Cancelado'],
    statuses: ['Recebido', 'Em preparo', 'Pronto para retirada', 'Saiu para entrega', 'Entregue', 'Cancelado'],
    defaultBenefits: [
      { titulo: 'Cardápio digital', texto: 'Produtos com fotos, descrição e preço.' },
      { titulo: 'Pedido pelo WhatsApp', texto: 'O cliente envia a mensagem pronta.' },
      { titulo: 'Entrega ou retirada', texto: 'O pedido já indica a forma escolhida.' },
      { titulo: 'Produtos com adicionais', texto: 'Prepare variações e complementos.' },
    ],
    defaultFaq: [
      { pergunta: 'Posso pedir para entrega?', resposta: 'Sim. A empresa informa entrega ou retirada conforme disponibilidade.' },
      { pergunta: 'O pagamento é online?', resposta: 'Nesta versão, o pagamento é combinado com a empresa pelo WhatsApp.' },
    ],
    defaultFeatures: [
      { titulo: 'Cardápio', texto: 'Itens organizados por categoria.' },
      { titulo: 'Carrinho', texto: 'Pedido montado antes de chamar no WhatsApp.' },
      { titulo: 'Adicionais', texto: 'Complementos e variações por item.' },
    ],
    features: ['cardapio', 'carrinho', 'adicionais', 'entrega', 'pix'],
    defaultPreviewItems: ['X-Burger', 'Pizza média', 'Refrigerante'],
  },
  {
    id: 'beauty',
    label: 'Estética e beleza',
    publicName: 'Orçaly Beauty',
    siteHeadline: 'Agende seus cuidados com praticidade.',
    siteSubheadline: 'Conheça nossos serviços, horários e formas de atendimento.',
    siteTitle: 'Agende seus cuidados com praticidade.',
    siteSubtitle: 'Conheça nossos serviços, horários e formas de atendimento.',
    cta: 'Agendar atendimento',
    orderLabel: 'Agendamento',
    productLabel: 'Serviço',
    defaultCategories: ['Serviços faciais', 'Sobrancelhas', 'Depilação', 'Cabelo', 'Pacotes'],
    defaultStatuses: ['Solicitado', 'Em análise', 'Agendado', 'Confirmado', 'Atendido', 'Cancelado'],
    statuses: ['Solicitado', 'Em análise', 'Agendado', 'Confirmado', 'Atendido', 'Cancelado'],
    defaultBenefits: [
      { titulo: 'Serviços bem apresentados', texto: 'Mostre valores, duração e benefícios.' },
      { titulo: 'Agendamento facilitado', texto: 'Leve o cliente para confirmar pelo WhatsApp.' },
      { titulo: 'Confiança visual', texto: 'Use galeria, depoimentos e FAQ.' },
    ],
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Serviços', texto: 'Lista organizada de atendimentos.' },
      { titulo: 'Horários', texto: 'Base preparada para agenda.' },
      { titulo: 'WhatsApp', texto: 'Confirmação rápida com a equipe.' },
    ],
    features: ['servicos', 'agenda_manual', 'whatsapp', 'galeria'],
    defaultPreviewItems: ['Limpeza de pele', 'Design de sobrancelha', 'Pacote especial'],
  },
  {
    id: 'barber',
    label: 'Barbearia',
    publicName: 'Orçaly Barber',
    siteHeadline: 'Cortes, barba e combos com agendamento simples.',
    siteSubheadline: 'Mostre serviços, profissionais e leve o cliente direto para o WhatsApp.',
    siteTitle: 'Cortes, barba e combos com agendamento simples.',
    siteSubtitle: 'Mostre serviços, profissionais e leve o cliente direto para o WhatsApp.',
    cta: 'Agendar horário',
    orderLabel: 'Agendamento',
    productLabel: 'Serviço',
    defaultCategories: ['Cortes', 'Barba', 'Combos', 'Tratamentos'],
    defaultStatuses: ['Solicitado', 'Agendado', 'Confirmado', 'Atendido', 'Cancelado'],
    statuses: ['Solicitado', 'Agendado', 'Confirmado', 'Atendido', 'Cancelado'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Serviços', texto: 'Cortes, barba e combos.' },
      { titulo: 'Profissionais', texto: 'Base preparada para equipe.' },
      { titulo: 'Horários', texto: 'Atendimento com agendamento manual.' },
    ],
    features: ['servicos', 'agenda_manual', 'combos', 'whatsapp'],
    defaultPreviewItems: ['Corte social', 'Barba completa', 'Combo premium'],
  },
  {
    id: 'technical_assistance',
    label: 'Assistência técnica',
    publicName: 'Orçaly Assistência',
    siteHeadline: 'Solicite análise técnica de forma organizada.',
    siteSubheadline: 'Envie fotos, defeitos, modelo do aparelho e acompanhe cada etapa.',
    siteTitle: 'Solicite análise técnica de forma organizada.',
    siteSubtitle: 'Envie fotos, defeitos, modelo do aparelho e acompanhe cada etapa.',
    cta: 'Solicitar análise',
    orderLabel: 'Ordem de serviço',
    productLabel: 'Serviço',
    defaultCategories: ['Celulares', 'Computadores', 'Eletrônicos', 'Orçamento técnico', 'Manutenção'],
    defaultStatuses: ['Recebido', 'Em diagnóstico', 'Aguardando aprovação', 'Em reparo', 'Pronto', 'Entregue', 'Cancelado'],
    statuses: ['Recebido', 'Em diagnóstico', 'Aguardando aprovação', 'Em reparo', 'Pronto', 'Entregue', 'Cancelado'],
    defaultBenefits: [
      { titulo: 'Solicitação com fotos', texto: 'Cliente envia imagens do aparelho ou problema.' },
      { titulo: 'Defeito e modelo', texto: 'Campos preparados para diagnóstico.' },
      { titulo: 'Status por etapa', texto: 'Acompanhe análise, proposta e reparo.' },
    ],
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Fotos', texto: 'Imagens ajudam no diagnóstico.' },
      { titulo: 'Defeito', texto: 'Descrição do problema no pedido.' },
      { titulo: 'Status', texto: 'Fluxo de análise e reparo.' },
    ],
    features: ['diagnostico', 'fotos', 'status', 'proposta'],
    defaultPreviewItems: ['Troca de tela', 'Notebook lento', 'Orçamento técnico'],
  },
  {
    id: 'auto',
    label: 'Oficina / auto',
    publicName: 'Orçaly Auto',
    siteHeadline: 'Solicite serviços automotivos com clareza.',
    siteSubheadline: 'Envie dados do veículo, fotos e detalhes para orçamento.',
    siteTitle: 'Solicite serviços automotivos com clareza.',
    siteSubtitle: 'Envie dados do veículo, fotos e detalhes para orçamento.',
    cta: 'Solicitar orçamento',
    orderLabel: 'Orçamento',
    productLabel: 'Serviço',
    defaultCategories: ['Revisão', 'Freios', 'Suspensão', 'Diagnóstico', 'Estética automotiva'],
    defaultStatuses: ['Recebido', 'Em análise', 'Aguardando peça', 'Aprovado', 'Em execução', 'Pronto', 'Entregue'],
    statuses: ['Recebido', 'Em análise', 'Aguardando peça', 'Aprovado', 'Em execução', 'Pronto', 'Entregue'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Dados do veículo', texto: 'Marca, modelo e ano para análise.' },
      { titulo: 'Fotos', texto: 'Cliente envia detalhes do serviço.' },
      { titulo: 'Histórico', texto: 'Organize atendimentos por cliente.' },
    ],
    features: ['veiculo', 'fotos', 'orcamento', 'historico'],
    defaultPreviewItems: ['Revisão básica', 'Troca de óleo', 'Diagnóstico'],
  },
  {
    id: 'store',
    label: 'Loja / comércio',
    publicName: 'Orçaly Loja',
    siteHeadline: 'Produtos, ofertas e pedidos em uma vitrine profissional.',
    siteSubheadline: 'Monte seu catálogo e receba pedidos pelo WhatsApp.',
    siteTitle: 'Produtos, ofertas e pedidos em uma vitrine profissional.',
    siteSubtitle: 'Monte seu catálogo e receba pedidos pelo WhatsApp.',
    cta: 'Comprar agora',
    orderLabel: 'Pedido',
    productLabel: 'Produto',
    defaultCategories: ['Produtos', 'Ofertas', 'Kits', 'Novidades'],
    defaultStatuses: ['Recebido', 'Separando', 'Pronto para retirada', 'Saiu para entrega', 'Entregue', 'Cancelado'],
    statuses: ['Recebido', 'Separando', 'Pronto para retirada', 'Saiu para entrega', 'Entregue', 'Cancelado'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Catálogo', texto: 'Produtos em uma vitrine digital.' },
      { titulo: 'Variações', texto: 'Tamanhos, cores e opções.' },
      { titulo: 'Pedidos', texto: 'Cliente chama com pedido organizado.' },
    ],
    features: ['catalogo', 'variacoes', 'pedidos', 'whatsapp'],
    defaultPreviewItems: ['Produto destaque', 'Kit promocional', 'Novidade'],
  },
  {
    id: 'events',
    label: 'Eventos',
    publicName: 'Orçaly Eventos',
    siteHeadline: 'Solicite pacotes e serviços para eventos.',
    siteSubheadline: 'Informe data, local, quantidade de pessoas e detalhes do evento.',
    siteTitle: 'Solicite pacotes e serviços para eventos.',
    siteSubtitle: 'Informe data, local, quantidade de pessoas e detalhes do evento.',
    cta: 'Solicitar orçamento',
    orderLabel: 'Solicitação',
    productLabel: 'Pacote',
    defaultCategories: ['Pacotes', 'Decoração', 'Buffet', 'Fotografia', 'Som e iluminação'],
    defaultStatuses: ['Recebido', 'Verificando data', 'Proposta enviada', 'Aprovado', 'Em preparação', 'Concluído', 'Cancelado'],
    statuses: ['Recebido', 'Verificando data', 'Proposta enviada', 'Aprovado', 'Em preparação', 'Concluído', 'Cancelado'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Datas', texto: 'Solicitações com data e local.' },
      { titulo: 'Pacotes', texto: 'Serviços organizados por evento.' },
      { titulo: 'Propostas', texto: 'Orçamentos claros para aprovação.' },
    ],
    features: ['data_evento', 'pacotes', 'orcamento', 'proposta'],
    defaultPreviewItems: ['Pacote festa', 'Decoração', 'Fotografia'],
  },
  {
    id: 'custom_products',
    label: 'Produtos personalizados',
    publicName: 'Orçaly Personalizados',
    siteHeadline: 'Personalizados, brindes e kits sob demanda.',
    siteSubheadline: 'Receba pedidos com detalhes, fotos, variações, medidas e aprovação.',
    siteTitle: 'Personalizados, brindes e kits sob demanda.',
    siteSubtitle: 'Receba pedidos com detalhes, fotos, variações, medidas e aprovação.',
    cta: 'Personalizar',
    orderLabel: 'Orçamento',
    productLabel: 'Produto',
    defaultCategories: ['Camisetas', 'Canecas', 'Brindes', 'Kits', 'Lembranças'],
    defaultStatuses: ['Recebido', 'Aguardando arte', 'Em análise', 'Aprovado', 'Em produção', 'Pronto', 'Entregue'],
    statuses: ['Recebido', 'Aguardando arte', 'Em análise', 'Aprovado', 'Em produção', 'Pronto', 'Entregue'],
    defaultBenefits,
    defaultFaq,
    defaultFeatures: [
      { titulo: 'Personalização', texto: 'Detalhes e variações do produto.' },
      { titulo: 'Fotos', texto: 'Referências visuais no pedido.' },
      { titulo: 'Aprovação', texto: 'Fluxo preparado para produção.' },
    ],
    features: ['variacoes', 'arte', 'personalizacao', 'aprovacao'],
    defaultPreviewItems: ['Caneca personalizada', 'Camiseta', 'Kit brinde'],
  },
]

export function normalizeBusinessType(type: unknown): BusinessType {
  const raw = String(type || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9_]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')

  return aliases[raw] || businessTypes.find((item) => item.id === raw)?.id || 'services'
}

export function getBusinessTypeConfig(type: unknown): BusinessTypeConfig {
  const normalized = normalizeBusinessType(type)
  return businessTypes.find((item) => item.id === normalized) || businessTypes[0]
}

export function getDefaultSetupForBusiness(type: unknown) {
  const config = getBusinessTypeConfig(type)

  return {
    business_type: config.id,
    site_template: config.id,
    site_layout: config.id === 'food' ? 'food-menu' : config.id === 'graphic' ? 'budget-showcase' : 'premium',
    site_cta_text: config.cta,
    site_marketplace_title: config.id === 'food' ? 'Cardápio' : config.id === 'beauty' || config.id === 'barber' ? 'Serviços' : 'Catálogo',
    site_marketplace_subtitle: config.id === 'food'
      ? 'Escolha os itens, monte seu pedido e envie pelo WhatsApp.'
      : 'Escolha produtos ou serviços e envie tudo organizado para atendimento.',
    site_cart_button_text: config.id === 'food' ? 'Adicionar ao pedido' : 'Adicionar',
    site_checkout_button_text: config.id === 'food' ? 'Enviar pedido' : 'Finalizar pedido',
    site_empty_catalog_text: config.id === 'food'
      ? 'O cardápio ainda está sendo preparado.'
      : 'A empresa ainda está preparando o catálogo.',
    site_payment_methods: config.id === 'food' ? ['Pix', 'Dinheiro', 'Cartão na entrega'] : ['Pix', 'Cartão', 'A combinar'],
    site_delivery_options: config.id === 'food' ? ['Retirada', 'Entrega'] : ['Retirada', 'Entrega', 'A combinar'],
    site_headline: config.siteHeadline,
    site_subheadline: config.siteSubheadline,
    site_about_title: `Sobre ${config.publicName}`,
    site_about_text: 'Esta empresa usa o Orçaly para organizar pedidos, atendimentos e informações em uma experiência profissional.',
    site_benefits: config.defaultBenefits,
    site_faq: config.defaultFaq,
    site_features: config.defaultFeatures,
    site_updated_at: new Date().toISOString(),
  }
}
export type BusinessMenuItem = {
  title: string
  description: string
  href: string
  badge?: string
  prepared?: boolean
}

export function getMenuByBusinessType(type: unknown): BusinessMenuItem[] {
  const config = getBusinessTypeConfig(type)

  const common: BusinessMenuItem[] = [
    { title: 'Dashboard', description: 'Resumo da operação.', href: '/painel' },
    { title: `${config.orderLabel}s`, description: 'Acompanhe solicitações, status e atendimento.', href: '/painel/pedidos' },
    { title: `${config.productLabel}s`, description: 'Cadastre itens, fotos, preços e disponibilidade.', href: '/painel/produtos' },
    { title: 'Clientes', description: 'Histórico, contatos e relacionamento.', href: '/painel/clientes' },
    { title: 'Site', description: 'Edite página pública, cores, textos e catálogo.', href: '/painel/site' },
    { title: 'Configurações', description: 'Empresa, recebimentos, equipe e preferências.', href: '/painel/configuracoes' },
    { title: 'Assinatura', description: 'Plano, renovação e pagamento.', href: '/assinatura' },
  ]

  if (config.id === 'food') {
    return [
      ...common,
      { title: 'Cardápio', description: 'Itens, categorias, adicionais e disponibilidade.', href: '/painel/produtos', badge: 'Food' },
      { title: 'Pedidos do dia', description: 'Pedidos recebidos para preparo, retirada ou entrega.', href: '/painel/pedidos', badge: 'Food' },
      { title: 'Entregas', description: 'Módulo de entrega em preparação para este segmento.', href: '/painel/modulos/entregas', prepared: true },
      { title: 'Horários', description: 'Configure horários de funcionamento.', href: '/painel/modulos/horarios', prepared: true },
      { title: 'Taxas de entrega', description: 'Configure bairros, taxas e pedido mínimo.', href: '/painel/modulos/taxas-entrega', prepared: true },
    ]
  }

  if (config.id === 'graphic' || config.id === 'custom_products') {
    return [
      ...common,
      { title: 'Orçamentos', description: 'Receba medidas, quantidades, arquivos e observações.', href: '/painel/pedidos', badge: 'Gráfica' },
      { title: 'Artes', description: 'Acompanhe arquivos enviados pelos clientes.', href: '/painel/modulos/artes', prepared: true },
      { title: 'Produção', description: 'Controle etapas, prazos e responsáveis.', href: '/painel/producao' },
      { title: 'Aprovação de arte', description: 'Módulo de aprovação em preparação.', href: '/painel/modulos/aprovacao-arte', prepared: true },
    ]
  }

  if (config.id === 'beauty' || config.id === 'barber') {
    return [
      ...common,
      { title: 'Agenda', description: 'Agendamentos em preparação para este segmento.', href: '/painel/modulos/agenda', prepared: true },
      { title: 'Serviços', description: 'Configure serviços, pacotes, duração e preço.', href: '/painel/produtos' },
      { title: 'Profissionais', description: 'Equipe e profissionais em preparação.', href: '/painel/modulos/profissionais', prepared: true },
      { title: 'Horários', description: 'Horários de atendimento em preparação.', href: '/painel/modulos/horarios', prepared: true },
    ]
  }

  if (config.id === 'technical_assistance') {
    return [
      ...common,
      { title: 'Ordens de serviço', description: 'Solicitações, defeitos, análise e proposta.', href: '/painel/pedidos', badge: 'Assistência' },
      { title: 'Diagnósticos', description: 'Módulo de diagnóstico em preparação.', href: '/painel/modulos/diagnosticos', prepared: true },
    ]
  }

  if (config.id === 'auto') {
    return [
      ...common,
      { title: 'Orçamentos auto', description: 'Serviços, veículo, análise e status.', href: '/painel/pedidos', badge: 'Auto' },
      { title: 'Veículos', description: 'Módulo de veículos em preparação.', href: '/painel/modulos/veiculos', prepared: true },
    ]
  }

  if (config.id === 'store') {
    return [
      ...common,
      { title: 'Catálogo', description: 'Produtos, variações, fotos e disponibilidade.', href: '/painel/produtos', badge: 'Loja' },
      { title: 'Pedidos da loja', description: 'Pedidos recebidos pela vitrine digital.', href: '/painel/pedidos', badge: 'Loja' },
    ]
  }

  if (config.id === 'events') {
    return [
      ...common,
      { title: 'Pacotes', description: 'Pacotes, datas e serviços para eventos.', href: '/painel/produtos', badge: 'Eventos' },
      { title: 'Solicitações', description: 'Pedidos de orçamento para eventos.', href: '/painel/pedidos', badge: 'Eventos' },
    ]
  }

  return common
}
