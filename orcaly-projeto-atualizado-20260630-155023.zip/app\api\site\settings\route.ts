import { NextRequest, NextResponse } from 'next/server'
import { getSiteTemplate, siteTemplates, templateToCompanyPatch } from '@/lib/orcaly-site-templates'
import { getCompanyAccess, getRequester, getSupabaseAdmin } from '@/lib/company-access'

const allowedFields = [
  'nome',
  'logo_url',
  'whatsapp',
  'instagram',
  'cidade',
  'estado',
  'marketplace_endereco',
  'marketplace_mapa_url',
  'atendimento_horario',
  'atendimento_observacao',
  'site_publico_ativo',
  'site_template',
  'site_layout',
  'site_art_style',
  'site_art_variant',
  'site_font_style',
  'site_button_style',
  'site_hero_alignment',
  'site_hero_style',
  'site_section_style',
  'site_product_card_style',
  'site_nav_variant',
  'site_corner_style',
  'site_density',
  'site_primary_color',
  'site_accent_color',
  'site_background_color',
  'site_text_color',
  'site_card_color',
  'site_badge_text',
  'site_headline',
  'site_subheadline',
  'site_cta_text',
  'site_secondary_cta_text',
  'site_banner_url',
  'site_whatsapp_message',
  'site_about_title',
  'site_about_text',
  'site_services_title',
  'site_contact_title',
  'site_show_store',
  'site_show_marketplace',
  'site_show_about',
  'site_show_contact',
  'site_show_featured',
  'site_show_faq',
  'site_show_testimonials',
  'site_show_gallery',
  'site_show_benefits',
  'site_enable_cart',
  'site_enable_coupons',
  'site_show_prices',
  'site_checkout_mode',
  'site_marketplace_title',
  'site_marketplace_subtitle',
  'site_cart_button_text',
  'site_checkout_button_text',
  'site_empty_catalog_text',
  'site_features',
  'site_faq',
  'site_testimonials',
  'site_gallery',
  'site_benefits',
  'site_custom_sections',
  'site_hero_highlights',
  'site_brand_words',
  'site_trust_title',
  'site_footer_text',
  'site_seo_title',
  'site_seo_description',
  'site_keywords',
  'site_promo_title',
  'site_promo_text',
  'site_promo_active',
  'site_promo_button_text',
  'site_business_hours',
  'site_payment_methods',
  'site_delivery_options',
]

function cleanPayload(input: Record<string, any>) {
  const output: Record<string, any> = {}

  allowedFields.forEach((field) => {
    if (input[field] !== undefined) output[field] = input[field]
  })

  output.site_updated_at = new Date().toISOString()
  return output
}

export async function GET(request: NextRequest) {
  try {
    const supabaseAdmin = getSupabaseAdmin()
    const requester = await getRequester(request, supabaseAdmin)

    if (!requester) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

    const access = await getCompanyAccess(supabaseAdmin, requester.id, requester.email)
    if (!access.company?.id) return NextResponse.json({ error: 'Empresa não encontrada.' }, { status: 404 })

    return NextResponse.json({
      company: access.company,
      templates: siteTemplates,
      currentTemplate: getSiteTemplate(access.company.site_template || access.company.modelo_negocio),
      permissions: {
        can_config: access.canConfig,
        can_manage: access.canManage,
      },
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erro ao carregar configurações do site.'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabaseAdmin = getSupabaseAdmin()
    const requester = await getRequester(request, supabaseAdmin)

    if (!requester) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

    const access = await getCompanyAccess(supabaseAdmin, requester.id, requester.email)
    if (!access.company?.id) return NextResponse.json({ error: 'Empresa não encontrada.' }, { status: 404 })
    if (!access.canManage) return NextResponse.json({ error: 'Seu perfil não pode editar o site.' }, { status: 403 })

    const body = await request.json()
    const update = cleanPayload(body)

    const { data, error } = await supabaseAdmin
      .from('companies')
      .update(update)
      .eq('id', access.company.id)
      .select('*')
      .single()

    if (error) throw error

    return NextResponse.json({ ok: true, company: data })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erro ao salvar configurações do site.'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = getSupabaseAdmin()
    const requester = await getRequester(request, supabaseAdmin)

    if (!requester) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

    const access = await getCompanyAccess(supabaseAdmin, requester.id, requester.email)
    if (!access.company?.id) return NextResponse.json({ error: 'Empresa não encontrada.' }, { status: 404 })
    if (!access.canManage) return NextResponse.json({ error: 'Seu perfil não pode aplicar template.' }, { status: 403 })

    const body = await request.json()
    const templateId = String(body.template || body.site_template || '')
    const template = getSiteTemplate(templateId)
    const patch = templateToCompanyPatch(templateId)

    const enhancedPatch = {
      ...patch,
      site_hero_style: body.site_hero_style || 'premium-showcase',
      site_art_variant: body.site_art_variant || 'auto',
      site_section_style: body.site_section_style || 'soft-premium',
      site_product_card_style: body.site_product_card_style || 'premium',
      site_nav_variant: body.site_nav_variant || 'clean',
      site_corner_style: body.site_corner_style || 'rounded',
      site_density: body.site_density || 'comfortable',
      site_show_marketplace: true,
      site_enable_cart: true,
      site_enable_coupons: true,
      site_show_prices: true,
      site_marketplace_title: template.id === 'imobiliaria' ? 'Imóveis em destaque' : template.id === 'alimenticio' ? 'Cardápio e encomendas' : 'Catálogo online',
      site_marketplace_subtitle: template.id === 'imobiliaria'
        ? 'Veja opções, escolha o imóvel de interesse e solicite atendimento consultivo.'
        : template.id === 'alimenticio'
          ? 'Escolha produtos, monte seu pedido e combine retirada ou entrega.'
          : 'Escolha produtos, monte seu pedido e envie tudo organizado para atendimento.',
      site_cart_button_text: template.id === 'imobiliaria' ? 'Tenho interesse' : 'Adicionar',
      site_checkout_button_text: template.id === 'imobiliaria' ? 'Solicitar atendimento' : 'Finalizar pedido',
      site_trust_title: template.id === 'imobiliaria' ? 'Atendimento imobiliário com clareza' : 'Por que escolher a gente?',
      site_brand_words: template.keywords || [],
    }

    const { data, error } = await supabaseAdmin
      .from('companies')
      .update({
        ...enhancedPatch,
        site_publico_ativo: true,
        site_updated_at: new Date().toISOString(),
      })
      .eq('id', access.company.id)
      .select('*')
      .single()

    if (error) throw error

    return NextResponse.json({
      ok: true,
      company: data,
      template,
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erro ao aplicar template.'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
