'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

type Company = {
  id: string
  nome?: string | null
  slug?: string | null
  logo_url?: string | null
  assinatura_status?: string | null
  assinatura_plano?: string | null
  plano?: string | null
  site_publico_ativo?: boolean | null
  site_template?: string | null
  whatsapp?: string | null
  whatsapp_enabled?: boolean | null
}

type Metrics = {
  pedidosHoje: number
  pedidosTotal: number
  propostasTotal: number
  produtosTotal: number
  cuponsTotal: number
  faturamentoEstimado: number
  pedidosPendentes: number
}

type QuickLinkGroup = 'principal' | 'vendas' | 'site' | 'operacao' | 'gestao'

type QuickLink = {
  title: string
  description: string
  href: string
  badge?: string
  group: QuickLinkGroup
}

const quickLinks: QuickLink[] = [
  {
    title: 'Checklist inicial',
    description: 'Configure empresa, site, produtos, cupom e WhatsApp.',
    href: '/painel/setup',
    badge: 'Novo',
    group: 'principal',
  },
  {
    title: 'Assistente IA',
    description: 'Crie textos, produtos, campanhas e ideias para o negócio.',
    href: '/painel/assistente',
    badge: 'IA',
    group: 'principal',
  },
  {
    title: 'Notificações',
    description: 'Alertas do sistema, tarefas, CRM e eventos importantes.',
    href: '/painel/notificacoes',
    badge: 'Novo',
    group: 'principal',
  },
  {
    title: 'Central Operacional',
    description: 'Modo balcão, QR Code, recorrência, cliente final e IA de orçamento.',
    href: '/painel/central-operacional',
    badge: 'Pro',
    group: 'principal',
  },

  {
    title: 'Pedidos',
    description: 'Acompanhe solicitações recebidas e status do atendimento.',
    href: '/painel/pedidos',
    group: 'vendas',
  },
  {
    title: 'Propostas',
    description: 'Gerencie propostas enviadas, pendentes e aprovadas.',
    href: '/painel/propostas',
    group: 'vendas',
  },
  {
    title: 'Orçamento inteligente',
    description: 'Transforme pedido bagunçado em orçamento organizado.',
    href: '/painel/orcamento-inteligente',
    badge: 'IA',
    group: 'vendas',
  },
  {
    title: 'CRM',
    description: 'Funil comercial, leads, negociações e clientes recorrentes.',
    href: '/painel/crm',
    badge: 'Novo',
    group: 'vendas',
  },

  {
    title: 'Catálogo',
    description: 'Produtos, serviços, preços, fotos, vídeos e destaque.',
    href: '/painel/produtos',
    group: 'site',
  },
  {
    title: 'IA de produtos',
    description: 'Gere descrições, benefícios e perguntas para catálogo.',
    href: '/painel/produtos/ia',
    badge: 'IA',
    group: 'site',
  },
  {
    title: 'Editor do site',
    description: 'Templates, cores, capa, seções, SEO, logo e banner.',
    href: '/painel/site',
    group: 'site',
  },
  {
    title: 'Cupons',
    description: 'Crie descontos com validade, pedido mínimo e limite máximo.',
    href: '/painel/cupons',
    badge: 'Novo',
    group: 'site',
  },

  {
    title: 'WhatsApp',
    description: 'Configure atendimento, webhook, IA e notificações.',
    href: '/painel/whatsapp',
    badge: 'Novo',
    group: 'operacao',
  },
  {
    title: 'Produção',
    description: 'Controle execução, responsáveis, prazos e status.',
    href: '/painel/producao',
    group: 'operacao',
  },
  {
    title: 'Tarefas',
    description: 'Lembretes, responsáveis, prazos e pendências internas.',
    href: '/painel/tarefas',
    badge: 'Novo',
    group: 'operacao',
  },

  {
    title: 'Clientes',
    description: 'Consulte clientes, histórico e oportunidades de retorno.',
    href: '/painel/clientes',
    group: 'gestao',
  },
  {
    title: 'Oportunidades',
    description: 'Acompanhe leads, chances de venda e próximos contatos.',
    href: '/painel/oportunidades',
    group: 'gestao',
  },
  {
    title: 'Financeiro',
    description: 'Veja estimativas, valores, recebimentos e controle básico.',
    href: '/painel/financeiro',
    group: 'gestao',
  },
  {
    title: 'Equipe',
    description: 'Gerencie membros, cargos e permissões.',
    href: '/painel/configuracoes/equipe',
    group: 'gestao',
  },
  {
    title: 'Configurações',
    description: 'Dados da empresa, endereço, WhatsApp e preferências.',
    href: '/painel/configuracoes',
    group: 'gestao',
  },
  {
    title: 'Auditoria',
    description: 'Saúde do sistema, integrações e últimas ações.',
    href: '/painel/auditoria',
    badge: 'Admin',
    group: 'gestao',
  },
  {
    title: 'Assinatura',
    description: 'Plano atual, renovação e pagamento.',
    href: '/assinatura',
    group: 'gestao',
  },
]

function moeda(value: number) {
  return Number(value || 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  })
}

function planoLabel(value?: string | null) {
  if (value === 'basico') return 'Básico'
  if (value === 'profissional') return 'Profissional'
  if (value === 'premium') return 'Premium'
  return 'Não definido'
}

function todayIsoStart() {
  const date = new Date()
  date.setHours(0, 0, 0, 0)
  return date.toISOString()
}

function MetricCard({ title, value, description }: { title: string; value: string | number; description: string }) {
  return (
    <article className="rounded-[1.6rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
      <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">{title}</p>
      <p className="mt-3 text-3xl font-black tracking-[-0.05em] text-[#071b3a]">{value}</p>
      <p className="mt-2 text-sm font-bold leading-6 text-slate-500">{description}</p>
    </article>
  )
}

function ActionCard({ link }: { link: QuickLink }) {
  return (
    <Link
      href={link.href}
      className="group rounded-[1.6rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5 transition hover:-translate-y-1 hover:border-[#05245c] hover:shadow-2xl hover:shadow-blue-950/10"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-black tracking-[-0.03em] text-[#071b3a]">{link.title}</h3>
          <p className="mt-2 text-sm font-bold leading-6 text-slate-500">{link.description}</p>
        </div>

        {link.badge ? (
          <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-[#05245c]">
            {link.badge}
          </span>
        ) : null}
      </div>

      <p className="mt-5 text-sm font-black text-[#05245c]">
        Abrir →
      </p>
    </Link>
  )
}

function SetupProgress({ company, metrics }: { company: Company | null; metrics: Metrics }) {
  const steps = [
    Boolean(company?.nome && company?.whatsapp),
    Boolean(company?.site_template && company?.site_publico_ativo),
    Boolean(company?.logo_url),
    metrics.produtosTotal > 0,
    metrics.cuponsTotal > 0,
    Boolean(company?.whatsapp_enabled),
  ]

  const done = steps.filter(Boolean).length
  const percent = Math.round((done / steps.length) * 100)

  return (
    <article className="rounded-[1.8rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Setup</p>
          <h2 className="mt-2 text-2xl font-black tracking-[-0.04em] text-[#071b3a]">Empresa pronta para vender</h2>
          <p className="mt-2 text-sm font-bold leading-6 text-slate-500">
            Complete os passos essenciais para deixar o Orçaly funcionando de verdade, não só bonito na tela.
          </p>
        </div>

        <div className="shrink-0 rounded-2xl bg-[#f5f8ff] px-5 py-4 text-center">
          <p className="text-3xl font-black text-[#05245c]">{percent}%</p>
          <p className="text-xs font-black text-slate-400">{done}/{steps.length}</p>
        </div>
      </div>

      <div className="mt-5 h-3 overflow-hidden rounded-full bg-[#f5f8ff]">
        <div className="h-full rounded-full bg-[#05245c]" style={{ width: `${percent}%` }} />
      </div>

      <Link href="/painel/setup" className="mt-5 inline-flex rounded-2xl bg-[#05245c] px-5 py-3 text-sm font-black text-white">
        Ver checklist
      </Link>
    </article>
  )
}

async function safeCount(table: string, companyId: string) {
  try {
    const { count } = await supabase
      .from(table)
      .select('id', { count: 'exact', head: true })
      .eq('company_id', companyId)

    return count || 0
  } catch {
    return 0
  }
}

export default function PainelProPage() {
  const [company, setCompany] = useState<Company | null>(null)
  const [metrics, setMetrics] = useState<Metrics>({
    pedidosHoje: 0,
    pedidosTotal: 0,
    propostasTotal: 0,
    produtosTotal: 0,
    cuponsTotal: 0,
    faturamentoEstimado: 0,
    pedidosPendentes: 0,
  })
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState('')

  async function loadPanel() {
    setLoading(true)
    setErro('')

    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const token = sessionData.session?.access_token

      if (!token) {
        window.location.href = '/login'
        return
      }

      const companyResponse = await fetch('/api/company/current', {
        headers: { Authorization: `Bearer ${token}` },
      })

      const companyPayload = await companyResponse.json().catch(() => ({}))

      if (!companyResponse.ok) {
        throw new Error(companyPayload.error || 'Erro ao carregar empresa.')
      }

      const currentCompany = companyPayload.company as Company
      setCompany(currentCompany)

      const companyId = currentCompany.id
      const start = todayIsoStart()

      const [ordersTotalResult, ordersTodayResult, ordersPendingResult] = await Promise.all([
        supabase.from('orders').select('id, preco_estimado, valor_total, status', { count: 'exact' }).eq('company_id', companyId).limit(1000),
        supabase.from('orders').select('id', { count: 'exact', head: true }).eq('company_id', companyId).gte('created_at', start),
        supabase.from('orders').select('id', { count: 'exact', head: true }).eq('company_id', companyId).in('status', ['Recebido', 'Pendente', 'Em análise', 'Aguardando aprovação']),
      ])

      const [propostasTotal, produtosTotal, cuponsTotal] = await Promise.all([
        safeCount('proposals', companyId),
        safeCount('products', companyId),
        safeCount('marketplace_coupons', companyId),
      ])

      const orders = ordersTotalResult.data || []
      const faturamento = orders.reduce((acc: number, order: any) => {
        return acc + Number(order.valor_total || order.preco_estimado || 0)
      }, 0)

      setMetrics({
        pedidosHoje: ordersTodayResult.count || 0,
        pedidosTotal: ordersTotalResult.count || orders.length || 0,
        propostasTotal,
        produtosTotal,
        cuponsTotal,
        faturamentoEstimado: faturamento,
        pedidosPendentes: ordersPendingResult.count || 0,
      })
    } catch (error) {
      setErro(error instanceof Error ? error.message : 'Erro ao carregar painel.')
    }

    setLoading(false)
  }

  useEffect(() => {
    loadPanel()
  }, [])

  const principal = useMemo(() => quickLinks.filter((item) => item.group === 'principal'), [])
  const vendas = useMemo(() => quickLinks.filter((item) => item.group === 'vendas'), [])
  const site = useMemo(() => quickLinks.filter((item) => item.group === 'site'), [])
  const operacao = useMemo(() => quickLinks.filter((item) => item.group === 'operacao'), [])
  const gestao = useMemo(() => quickLinks.filter((item) => item.group === 'gestao'), [])

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f8ff] px-4">
        <div className="rounded-[2rem] bg-white p-8 text-center font-black text-[#071b3a] shadow-xl shadow-blue-950/5">
          Carregando painel...
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#f5f8ff] px-4 py-6 text-[#071b3a]">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="overflow-hidden rounded-[2rem] border border-blue-100 bg-white shadow-xl shadow-blue-950/5">
          <div className="grid gap-6 p-6 lg:grid-cols-[1fr_360px] lg:items-center">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                {company?.logo_url ? (
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white shadow-lg ring-1 ring-blue-100">
                    <img src={company.logo_url} alt={company.nome || 'Logo'} className="max-h-[78%] max-w-[78%] object-contain" />
                  </span>
                ) : (
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#05245c] text-xl font-black text-white">
                    {company?.nome?.slice(0, 1) || 'O'}
                  </span>
                )}

                <div>
                  <p className="text-xs font-black uppercase tracking-[0.22em] text-[#05245c]">Painel Orçaly</p>
                  <h1 className="mt-1 text-4xl font-black tracking-[-0.06em] sm:text-5xl">
                    {company?.nome || 'Sua empresa'}
                  </h1>
                </div>
              </div>

              <p className="mt-5 max-w-3xl text-base font-bold leading-7 text-slate-500">
                Controle pedidos, propostas, catálogo, site, cupons, WhatsApp, produção, CRM, tarefas e IA em uma área mais organizada.
              </p>

              <div className="mt-6 flex flex-wrap gap-2">
                <span className="rounded-full bg-blue-50 px-4 py-2 text-sm font-black text-[#05245c]">
                  Plano: {planoLabel(company?.assinatura_plano || company?.plano)}
                </span>
                <span className="rounded-full bg-emerald-50 px-4 py-2 text-sm font-black text-emerald-700">
                  Site: {company?.site_publico_ativo ? 'Ativo' : 'Inativo'}
                </span>
                <span className="rounded-full bg-slate-100 px-4 py-2 text-sm font-black text-slate-600">
                  Slug: {company?.slug || 'não definido'}
                </span>
              </div>
            </div>

            <div className="rounded-[1.7rem] bg-[#05245c] p-5 text-white">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-white/55">Ação rápida</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Continue configurando</h2>
              <p className="mt-2 text-sm font-bold leading-6 text-white/70">
                Comece pelo checklist se ainda estiver montando a operação.
              </p>
              <div className="mt-5 grid gap-2">
                <Link href="/painel/setup" className="rounded-2xl bg-white px-5 py-3 text-center text-sm font-black text-[#05245c]">
                  Abrir checklist
                </Link>
                {company?.slug ? (
                  <a href={`/site/${company.slug}`} target="_blank" rel="noreferrer" className="rounded-2xl bg-white/10 px-5 py-3 text-center text-sm font-black text-white">
                    Ver site público
                  </a>
                ) : null}
              </div>
            </div>
          </div>
        </header>

        {erro ? (
          <div className="rounded-2xl border border-red-100 bg-red-50 p-4 font-bold text-red-700">
            {erro}
          </div>
        ) : null}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard title="Pedidos hoje" value={metrics.pedidosHoje} description="Pedidos criados desde meia-noite." />
          <MetricCard title="Pedidos pendentes" value={metrics.pedidosPendentes} description="Demandas que precisam de atenção." />
          <MetricCard title="Produtos" value={metrics.produtosTotal} description="Itens cadastrados no catálogo." />
          <MetricCard title="Faturamento estimado" value={moeda(metrics.faturamentoEstimado)} description="Soma estimada dos pedidos carregados." />
        </div>

        <SetupProgress company={company} metrics={metrics} />

        <section className="rounded-[2rem] border border-blue-100 bg-white/70 p-5 shadow-xl shadow-blue-950/5">
          <div className="mb-5">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Comece por aqui</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Módulos principais</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {principal.map((link) => <ActionCard key={link.href} link={link} />)}
          </div>
        </section>

        <div className="grid gap-6 xl:grid-cols-2">
          <section className="rounded-[2rem] border border-blue-100 bg-white/70 p-5 shadow-xl shadow-blue-950/5">
            <div className="mb-5">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Vendas</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Pedidos, propostas e CRM</h2>
            </div>
            <div className="grid gap-4">
              {vendas.map((link) => <ActionCard key={link.href} link={link} />)}
            </div>
          </section>

          <section className="rounded-[2rem] border border-blue-100 bg-white/70 p-5 shadow-xl shadow-blue-950/5">
            <div className="mb-5">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Site</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Site, catálogo e cupons</h2>
            </div>
            <div className="grid gap-4">
              {site.map((link) => <ActionCard key={link.href} link={link} />)}
            </div>
          </section>

          <section className="rounded-[2rem] border border-blue-100 bg-white/70 p-5 shadow-xl shadow-blue-950/5">
            <div className="mb-5">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Operação</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Produção, tarefas e atendimento</h2>
            </div>
            <div className="grid gap-4">
              {operacao.map((link) => <ActionCard key={link.href} link={link} />)}
            </div>
          </section>

          <section className="rounded-[2rem] border border-blue-100 bg-white/70 p-5 shadow-xl shadow-blue-950/5">
            <div className="mb-5">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#05245c]">Gestão</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">Clientes, equipe, financeiro e sistema</h2>
            </div>
            <div className="grid gap-4">
              {gestao.map((link) => <ActionCard key={link.href} link={link} />)}
            </div>
          </section>
        </div>
      </section>
    </main>
  )
}
