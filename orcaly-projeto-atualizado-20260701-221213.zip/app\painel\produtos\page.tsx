'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { getCurrentCompanyClient } from '@/lib/current-company-client'

type Empresa = {
  id: string
  nome: string
  slug: string
}

type ItemCatalogo = {
  id: string
  nome: string
  descricao: string | null
  categoria: string | null
  tipo: string | null
  unidade: string | null
  preco: number
  ativo: boolean
  destaque: boolean | null
  imagem_url: string | null
  image_urls?: string[] | null
  video_url?: string | null
  business_type?: string | null
  available?: boolean | null
  addons?: any[] | null
  variations?: any[] | null
  extras?: Record<string, any> | null
  company_id: string | null
  created_at: string
  precificacao: string | null
  unidade_label: string | null
  permite_largura: boolean | null
  permite_altura: boolean | null
  permite_comprimento: boolean | null
  permite_quantidade: boolean | null
  valor_minimo: number | null
  cobrar_sinal_personalizado: boolean | null
  percentual_sinal_produto: number | null
}

const tiposPrecificacao = [
  {
    id: 'unidade',
    nome: 'Unidade',
    descricao: 'Preço x quantidade.',
    unidade: 'unidade',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'metro_quadrado',
    nome: 'Metro quadrado',
    descricao: 'Largura x altura x preço x quantidade.',
    unidade: 'm²',
    largura: true,
    altura: true,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'metro_linear',
    nome: 'Metro linear',
    descricao: 'Comprimento x preço x quantidade.',
    unidade: 'metro',
    largura: false,
    altura: false,
    comprimento: true,
    quantidade: true,
  },
  {
    id: 'milheiro',
    nome: 'Milheiro',
    descricao: 'Quantidade / 1000 x preço do milheiro.',
    unidade: 'milheiro',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'hora',
    nome: 'Hora',
    descricao: 'Horas x preço.',
    unidade: 'hora',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'diaria',
    nome: 'Diária',
    descricao: 'Diárias x preço.',
    unidade: 'diária',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'mensalidade',
    nome: 'Mensalidade',
    descricao: 'Meses x preço.',
    unidade: 'mês',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: true,
  },
  {
    id: 'sob_consulta',
    nome: 'Sob consulta',
    descricao: 'Não calcula automático. O cliente envia o pedido para orçamento.',
    unidade: 'orçamento',
    largura: false,
    altura: false,
    comprimento: false,
    quantidade: false,
  },
]

function formatarDinheiro(valor: number) {
  return valor.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  })
}

function limparNomeArquivo(nome: string) {
  return nome
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9.-]/g, '')
}

function numeroDoCampo(valor: string) {
  const numero = Number(valor.replace(',', '.'))

  if (Number.isNaN(numero)) return 0

  return numero
}

function nomePrecificacao(id: string | null) {
  return (
    tiposPrecificacao.find((tipo) => tipo.id === id)?.nome ||
    'Unidade'
  )
}

export default function ProdutosPage() {
  const router = useRouter()

  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [itens, setItens] = useState<ItemCatalogo[]>([])

  const [nome, setNome] = useState('')
  const [descricao, setDescricao] = useState('')
  const [categoria, setCategoria] = useState('')
  const [tipo, setTipo] = useState('produto')
  const [unidade, setUnidade] = useState('unidade')
  const [preco, setPreco] = useState('')
  const [destaque, setDestaque] = useState(false)
  const [arquivosImagens, setArquivosImagens] = useState<File[]>([])
  const [arquivoVideo, setArquivoVideo] = useState<File | null>(null)

  const [precificacao, setPrecificacao] = useState('unidade')
  const [unidadeLabel, setUnidadeLabel] = useState('unidade')
  const [permiteLargura, setPermiteLargura] = useState(false)
  const [permiteAltura, setPermiteAltura] = useState(false)
  const [permiteComprimento, setPermiteComprimento] = useState(false)
  const [permiteQuantidade, setPermiteQuantidade] = useState(true)
  const [valorMinimo, setValorMinimo] = useState('')
  const [cobrarSinalPersonalizado, setCobrarSinalPersonalizado] = useState(false)
  const [percentualSinalProduto, setPercentualSinalProduto] = useState('')

  const [editandoId, setEditandoId] = useState<string | null>(null)
  const [carregando, setCarregando] = useState(true)
  const [salvando, setSalvando] = useState(false)
  const [mensagem, setMensagem] = useState('')

  async function carregarDados() {
    setCarregando(true)
    setMensagem('')

    const { data: sessaoData } = await supabase.auth.getSession()
    const usuario = sessaoData.session?.user

    if (!usuario) {
      router.push('/login')
      return
    }

    let empresaData: Empresa

    try {
      const current = await getCurrentCompanyClient()
      empresaData = current.company as Empresa
    } catch (error) {
      setMensagem(error instanceof Error ? error.message : 'Nenhuma empresa vinculada a esta conta.')
      setCarregando(false)
      return
    }

    setEmpresa(empresaData)

    const { data: itensData, error: itensError } = await supabase
      .from('products')
      .select('*')
      .eq('company_id', empresaData.id)
      .eq('arquivado', false)
      .order('created_at', { ascending: false })

    if (itensError) {
      setMensagem(`Erro ao carregar catálogo: ${itensError.message}`)
      setCarregando(false)
      return
    }

    setItens(itensData || [])
    setCarregando(false)
  }

  async function enviarImagem(companyId: string, arquivo: File) {
    const nomeArquivo = limparNomeArquivo(arquivo.name)
    const caminho = `${companyId}/${Date.now()}-${nomeArquivo}`

    const { error } = await supabase.storage
      .from('produtos')
      .upload(caminho, arquivo, {
        cacheControl: '3600',
        upsert: true,
      })

    if (error) {
      throw new Error(error.message)
    }

    const { data } = supabase.storage.from('produtos').getPublicUrl(caminho)

    return data.publicUrl
  }


  async function enviarVideo(companyId: string, arquivo: File) {
    if (!arquivo.type.startsWith('video/')) {
      throw new Error('Envie um vídeo válido.')
    }

    if (arquivo.size > 50 * 1024 * 1024) {
      throw new Error('O vídeo precisa ter até 50 MB.')
    }

    const duracao = await obterDuracaoVideo(arquivo)

    if (duracao > 30.5) {
      throw new Error('O vídeo precisa ter no máximo 30 segundos.')
    }

    const nomeArquivo = limparNomeArquivo(arquivo.name)
    const caminho = `${companyId}/videos/${Date.now()}-${nomeArquivo}`

    const { error } = await supabase.storage.from('produtos').upload(caminho, arquivo, {
      cacheControl: '3600',
      upsert: true,
    })

    if (error) throw new Error(error.message)

    const { data } = supabase.storage.from('produtos').getPublicUrl(caminho)
    return data.publicUrl
  }

  function obterDuracaoVideo(arquivo: File) {
    return new Promise<number>((resolve, reject) => {
      const video = document.createElement('video')
      const url = URL.createObjectURL(arquivo)

      video.preload = 'metadata'
      video.onloadedmetadata = () => {
        URL.revokeObjectURL(url)
        resolve(video.duration || 0)
      }
      video.onerror = () => {
        URL.revokeObjectURL(url)
        reject(new Error('Não foi possível validar a duração do vídeo.'))
      }
      video.src = url
    })
  }

  function selecionarImagens(files: FileList | null) {
    const selecionadas = Array.from(files || []).filter((file) => file.type.startsWith('image/'))

    if (selecionadas.length > 4) {
      setMensagem('Você pode selecionar no máximo 4 fotos por item.')
    }

    setArquivosImagens(selecionadas.slice(0, 4))
  }

  function aplicarTipoPrecificacao(id: string) {
    const tipoSelecionado = tiposPrecificacao.find((item) => item.id === id)

    setPrecificacao(id)

    if (!tipoSelecionado) return

    setUnidadeLabel(tipoSelecionado.unidade)
    setUnidade(tipoSelecionado.unidade)
    setPermiteLargura(tipoSelecionado.largura)
    setPermiteAltura(tipoSelecionado.altura)
    setPermiteComprimento(tipoSelecionado.comprimento)
    setPermiteQuantidade(tipoSelecionado.quantidade)
  }

  function limparFormulario() {
    setNome('')
    setDescricao('')
    setCategoria('')
    setTipo('produto')
    setUnidade('unidade')
    setPreco('')
    setDestaque(false)
    setArquivosImagens([])
    setArquivoVideo(null)

    setPrecificacao('unidade')
    setUnidadeLabel('unidade')
    setPermiteLargura(false)
    setPermiteAltura(false)
    setPermiteComprimento(false)
    setPermiteQuantidade(true)
    setValorMinimo('')
    setCobrarSinalPersonalizado(false)
    setPercentualSinalProduto('')

    setEditandoId(null)
  }

  function preencherEdicao(item: ItemCatalogo) {
    setEditandoId(item.id)
    setNome(item.nome || '')
    setDescricao(item.descricao || '')
    setCategoria(item.categoria || '')
    setTipo(item.tipo || 'produto')
    setUnidade(item.unidade || item.unidade_label || 'unidade')
    setPreco(String(item.preco || ''))
    setDestaque(Boolean(item.destaque))

    setPrecificacao(item.precificacao || 'unidade')
    setUnidadeLabel(item.unidade_label || item.unidade || 'unidade')
    setPermiteLargura(Boolean(item.permite_largura))
    setPermiteAltura(Boolean(item.permite_altura))
    setPermiteComprimento(Boolean(item.permite_comprimento))
    setPermiteQuantidade(item.permite_quantidade !== false)
    setValorMinimo(String(item.valor_minimo || ''))
    setCobrarSinalPersonalizado(Boolean(item.cobrar_sinal_personalizado))
    setPercentualSinalProduto(String(item.percentual_sinal_produto || ''))

    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    })
  }

  async function salvarItem(evento: React.FormEvent) {
    evento.preventDefault()

    if (!empresa) return

    const precoNumero = numeroDoCampo(preco)
    const valorMinimoNumero = numeroDoCampo(valorMinimo)
    const percentualSinalNumero = numeroDoCampo(percentualSinalProduto)

    if (!nome || !tipo || Number.isNaN(precoNumero)) {
      setMensagem('Preencha nome, tipo e preço corretamente.')
      return
    }

    if (cobrarSinalPersonalizado && (percentualSinalNumero <= 0 || percentualSinalNumero > 100)) {
      setMensagem('O sinal do produto precisa ficar entre 1% e 100%.')
      return
    }

    setSalvando(true)
    setMensagem('')

    try {
      const itemAtual = editandoId ? itens.find((item) => item.id === editandoId) : null
      const imagensAtuais = Array.isArray(itemAtual?.image_urls)
        ? itemAtual?.image_urls?.filter(Boolean) || []
        : itemAtual?.imagem_url
          ? [itemAtual.imagem_url]
          : []
      const novasImagens = arquivosImagens.length
        ? await Promise.all(arquivosImagens.slice(0, 4).map((arquivo) => enviarImagem(empresa.id, arquivo)))
        : []
      const imageUrls = [...imagensAtuais, ...novasImagens].slice(0, 4)
      const videoUrl = arquivoVideo ? await enviarVideo(empresa.id, arquivoVideo) : itemAtual?.video_url || null
      const imagemUrl = imageUrls[0] || ''

      const dadosProduto = {
        nome,
        descricao,
        categoria,
        tipo,
        unidade: unidadeLabel || unidade,
        unidade_label: unidadeLabel || unidade,
        preco: precoNumero,
        destaque,
        imagem_url: imagemUrl || undefined,
        image_urls: imageUrls,
        video_url: videoUrl,
        precificacao,
        permite_largura: permiteLargura,
        permite_altura: permiteAltura,
        permite_comprimento: permiteComprimento,
        permite_quantidade: permiteQuantidade,
        valor_minimo: valorMinimoNumero,
        cobrar_sinal_personalizado: cobrarSinalPersonalizado,
        percentual_sinal_produto: cobrarSinalPersonalizado
          ? percentualSinalNumero
          : null,
        business_type: (empresa as any)?.business_type || 'services',
        available: true,
      }

      if (editandoId) {
        const { error } = await supabase
          .from('products')
          .update({
            ...dadosProduto,
            imagem_url: imagemUrl || itemAtual?.imagem_url || null,
            image_urls: imageUrls,
            video_url: videoUrl,
          })
          .eq('id', editandoId)
          .eq('company_id', empresa.id)

        if (error) {
          setMensagem(`Erro ao atualizar item: ${error.message}`)
          setSalvando(false)
          return
        }

        setMensagem('Item atualizado com sucesso.')
      } else {
        const { error } = await supabase.from('products').insert({
          company_id: empresa.id,
          ...dadosProduto,
          imagem_url: imagemUrl || null,
          ativo: true,
        })

        if (error) {
          setMensagem(`Erro ao cadastrar item: ${error.message}`)
          setSalvando(false)
          return
        }

        setMensagem('Item cadastrado com sucesso.')
      }

      limparFormulario()
      await carregarDados()
    } catch (erro) {
      const textoErro =
        erro instanceof Error ? erro.message : 'Erro desconhecido.'

      setMensagem(`Erro: ${textoErro}`)
    }

    setSalvando(false)
  }

  async function alternarAtivo(item: ItemCatalogo) {
    if (!empresa) return

    const { error } = await supabase
      .from('products')
      .update({ ativo: !item.ativo })
      .eq('id', item.id)
      .eq('company_id', empresa.id)

    if (error) {
      setMensagem(`Erro ao alterar status: ${error.message}`)
      return
    }

    setItens((listaAtual) =>
      listaAtual.map((produto) =>
        produto.id === item.id ? { ...produto, ativo: !produto.ativo } : produto
      )
    )
  }

  async function excluirItem(itemId: string) {
    if (!empresa) return

    const confirmar = confirm('Remover este item do catálogo? O histórico de pedidos será preservado.')

    if (!confirmar) return

    const { error } = await supabase
      .from('products')
      .update({
        ativo: false,
        arquivado: true,
        deleted_at: new Date().toISOString(),
      })
      .eq('id', itemId)
      .eq('company_id', empresa.id)

    if (error) {
      setMensagem(`Erro ao remover item: ${error.message}`)
      return
    }

    setItens((listaAtual) => listaAtual.filter((item) => item.id !== itemId))
    setMensagem('Item removido do catálogo.')
  }

  useEffect(() => {
    carregarDados()
  }, [])

  const itensAtivos = itens.filter((item) => item.ativo).length
  const servicos = itens.filter((item) => item.tipo === 'servico').length
  const itensMetragem = itens.filter((item) =>
    ['metro_quadrado', 'metro_linear'].includes(item.precificacao || '')
  ).length

  if (carregando) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-white px-4">
        <div className="rounded-[2rem] border border-blue-50 bg-white p-8 text-center shadow-xl shadow-blue-950/5">
          <img
            src="/logo-orcaly.png"
            alt="Orçaly"
            className="mx-auto mb-6 h-14 w-auto object-contain"
          />

          <p className="font-bold text-slate-500">
            Carregando catálogo...
          </p>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-white pb-24 text-slate-950">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute left-[-180px] top-[-180px] h-[420px] w-[420px] rounded-full bg-blue-100 blur-3xl" />
        <div className="absolute right-[-180px] top-[20%] h-[360px] w-[360px] rounded-full bg-cyan-100 blur-3xl" />
        <div className="absolute bottom-[-160px] left-[30%] h-[360px] w-[360px] rounded-full bg-emerald-100 blur-3xl" />
      </div>

      <section className="relative mx-auto w-full max-w-7xl px-4 py-5 sm:px-6">
        <header className="sticky top-4 z-30 flex flex-col gap-4 rounded-[2rem] border border-blue-50 bg-white/90 p-4 shadow-xl shadow-blue-950/5 backdrop-blur-xl lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-4">
            <img
              src="/icone-orcaly.png"
              alt="Orçaly"
              className="h-14 w-14 rounded-2xl bg-blue-50 object-contain p-2"
            />

            <div>
              <p className="text-xs font-black uppercase tracking-[0.25em] text-[#05245c]">
                Catálogo
              </p>

              <h1 className="mt-1 text-2xl font-black text-[#071b3a]">
                Produtos e serviços
              </h1>

              <p className="mt-1 text-sm font-medium text-slate-500">
                {empresa?.nome || 'Empresa'} • Preço por unidade, metragem, milheiro, hora ou diária.
              </p>
            </div>
          </div>

          <nav className="grid gap-2 sm:grid-cols-3 lg:flex">
            <Link
              href="/painel"
              className="rounded-2xl border border-blue-100 bg-white px-4 py-3 text-center text-sm font-black text-[#05245c] transition hover:bg-blue-50"
            >
              Painel
            </Link>

            <Link
              href="/painel/configuracoes"
              className="rounded-2xl border border-blue-100 bg-white px-4 py-3 text-center text-sm font-black text-[#05245c] transition hover:bg-blue-50"
            >
              Configurações
            </Link>

            <a
              href={empresa ? `/site/${empresa.slug}` : '#'}
              target="_blank"
              className="rounded-2xl bg-[#05245c] px-4 py-3 text-center text-sm font-black text-white transition hover:bg-[#031a43]"
            >
              Ver página
            </a>
          </nav>
        </header>

        {mensagem && (
          <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm font-bold text-[#05245c]">
            {mensagem}
          </div>
        )}

        <section className="mt-6 grid gap-4 sm:grid-cols-4">
          <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <p className="text-sm font-bold text-slate-500">
              Itens cadastrados
            </p>

            <p className="mt-3 text-4xl font-black text-[#071b3a]">
              {itens.length}
            </p>
          </div>

          <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <p className="text-sm font-bold text-slate-500">
              Ativos
            </p>

            <p className="mt-3 text-4xl font-black text-emerald-700">
              {itensAtivos}
            </p>
          </div>

          <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <p className="text-sm font-bold text-slate-500">
              Serviços
            </p>

            <p className="mt-3 text-4xl font-black text-[#05245c]">
              {servicos}
            </p>
          </div>

          <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <p className="text-sm font-bold text-slate-500">
              Por metragem
            </p>

            <p className="mt-3 text-4xl font-black text-[#05245c]">
              {itensMetragem}
            </p>
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
          <form
            onSubmit={salvarItem}
            className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5"
          >
            <div className="mb-6">
              <p className="text-sm font-black uppercase tracking-[0.25em] text-[#05245c]">
                {editandoId ? 'Editar item' : 'Novo item'}
              </p>

              <h2 className="mt-2 text-3xl font-black text-[#071b3a]">
                Configurar cobrança
              </h2>

              <p className="mt-2 text-sm text-slate-500">
                Aqui você decide se o cliente compra por unidade, metragem, milheiro, hora, diária ou orçamento.
              </p>
            </div>

            <div className="grid gap-4">
              <input
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Nome do produto ou serviço"
                className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
              />

              <textarea
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                placeholder="Descrição curta para o cliente entender o que está contratando"
                rows={4}
                className="resize-none rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value)}
                  placeholder="Categoria. Ex: impressão, manutenção, aluguel"
                  className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
                />

                <select
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value)}
                  className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-bold text-[#071b3a] outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
                >
                  <option value="produto">Produto</option>
                  <option value="servico">Serviço</option>
                  <option value="locacao">Locação</option>
                  <option value="assinatura">Assinatura</option>
                </select>
              </div>

              <label className="grid gap-2">
                <span className="text-sm font-black text-[#071b3a]">
                  Tipo de precificação
                </span>

                <select
                  value={precificacao}
                  onChange={(e) => aplicarTipoPrecificacao(e.target.value)}
                  className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-bold text-[#071b3a] outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
                >
                  {tiposPrecificacao.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.nome}
                    </option>
                  ))}
                </select>

                <span className="rounded-2xl bg-blue-50 px-4 py-3 text-sm font-bold text-[#05245c]">
                  {tiposPrecificacao.find((item) => item.id === precificacao)?.descricao}
                </span>
              </label>

              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  value={preco}
                  onChange={(e) => setPreco(e.target.value)}
                  placeholder="Preço base. Ex: 197"
                  className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
                />

                <input
                  value={unidadeLabel}
                  onChange={(e) => {
                    setUnidadeLabel(e.target.value)
                    setUnidade(e.target.value)
                  }}
                  placeholder="Nome da unidade. Ex: m², milheiro, hora"
                  className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
                />
              </div>

              <input
                value={valorMinimo}
                onChange={(e) => setValorMinimo(e.target.value)}
                placeholder="Valor mínimo. Ex: 50"
                className="rounded-2xl border border-blue-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-[#05245c] focus:ring-4 focus:ring-blue-100"
              />

              <div className="grid gap-3 rounded-3xl border border-blue-100 bg-blue-50 p-4">
                <p className="font-black text-[#071b3a]">
                  Campos que o cliente deverá preencher
                </p>

                <button
                  type="button"
                  onClick={() => setPermiteQuantidade(!permiteQuantidade)}
                  className={`rounded-2xl px-4 py-3 text-left font-black ${
                    permiteQuantidade
                      ? 'bg-white text-[#05245c]'
                      : 'bg-blue-100 text-slate-500'
                  }`}
                >
                  Quantidade
                </button>

                <button
                  type="button"
                  onClick={() => setPermiteLargura(!permiteLargura)}
                  className={`rounded-2xl px-4 py-3 text-left font-black ${
                    permiteLargura
                      ? 'bg-white text-[#05245c]'
                      : 'bg-blue-100 text-slate-500'
                  }`}
                >
                  Largura
                </button>

                <button
                  type="button"
                  onClick={() => setPermiteAltura(!permiteAltura)}
                  className={`rounded-2xl px-4 py-3 text-left font-black ${
                    permiteAltura
                      ? 'bg-white text-[#05245c]'
                      : 'bg-blue-100 text-slate-500'
                  }`}
                >
                  Altura
                </button>

                <button
                  type="button"
                  onClick={() => setPermiteComprimento(!permiteComprimento)}
                  className={`rounded-2xl px-4 py-3 text-left font-black ${
                    permiteComprimento
                      ? 'bg-white text-[#05245c]'
                      : 'bg-blue-100 text-slate-500'
                  }`}
                >
                  Comprimento
                </button>
              </div>

              <div className="grid gap-3 rounded-3xl border border-emerald-100 bg-emerald-50 p-4">
                <button
                  type="button"
                  onClick={() => setCobrarSinalPersonalizado(!cobrarSinalPersonalizado)}
                  className={`rounded-2xl px-4 py-4 text-left font-black ${
                    cobrarSinalPersonalizado
                      ? 'bg-white text-emerald-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  {cobrarSinalPersonalizado
                    ? 'Este item tem sinal próprio'
                    : 'Usar sinal padrão da empresa'}
                </button>

                {cobrarSinalPersonalizado && (
                  <input
                    value={percentualSinalProduto}
                    onChange={(e) => setPercentualSinalProduto(e.target.value)}
                    placeholder="Percentual do sinal. Ex: 50"
                    className="rounded-2xl border border-emerald-100 bg-white px-4 py-4 font-medium outline-none transition focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
                  />
                )}
              </div>

              <label className="grid cursor-pointer gap-2">
                <span className="text-sm font-black text-[#071b3a]">
                  Fotos do marketplace, até 4 imagens
                </span>

                <div className="rounded-2xl border border-dashed border-blue-200 bg-blue-50 px-4 py-5 text-sm font-bold text-[#05245c] transition hover:bg-blue-100">
                  {arquivosImagens.length
                    ? `${arquivosImagens.length} foto(s) selecionada(s)`
                    : 'Clique para enviar até 4 fotos do item'}
                </div>

                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => selecionarImagens(e.target.files)}
                  className="hidden"
                />
              </label>

              <label className="grid cursor-pointer gap-2">
                <span className="text-sm font-black text-[#071b3a]">
                  Vídeo curto, opcional, até 30 segundos
                </span>

                <div className="rounded-2xl border border-dashed border-emerald-200 bg-emerald-50 px-4 py-5 text-sm font-bold text-emerald-700 transition hover:bg-emerald-100">
                  {arquivoVideo ? arquivoVideo.name : 'Clique para enviar um vídeo MP4/WebM/MOV'}
                </div>

                <input
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,video/*"
                  onChange={(e) => setArquivoVideo(e.target.files?.[0] || null)}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={() => setDestaque(!destaque)}
                className={`rounded-2xl px-4 py-4 text-left font-black transition ${
                  destaque
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {destaque ? 'Item em destaque' : 'Marcar como destaque'}
              </button>

              <button
                disabled={salvando}
                className="rounded-2xl bg-[#05245c] px-5 py-4 font-black text-white shadow-lg shadow-blue-950/15 transition hover:-translate-y-1 hover:bg-[#031a43] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {salvando
                  ? 'Salvando...'
                  : editandoId
                    ? 'Salvar alterações'
                    : 'Cadastrar item'}
              </button>

              {editandoId && (
                <button
                  type="button"
                  onClick={limparFormulario}
                  className="rounded-2xl border border-blue-100 bg-white px-5 py-4 font-black text-[#05245c] transition hover:bg-blue-50"
                >
                  Cancelar edição
                </button>
              )}
            </div>
          </form>

          <section className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
              <div>
                <p className="text-sm font-black uppercase tracking-[0.25em] text-[#05245c]">
                  Catálogo
                </p>

                <h2 className="mt-2 text-3xl font-black text-[#071b3a]">
                  Itens cadastrados
                </h2>
              </div>

              <button
                onClick={carregarDados}
                className="rounded-2xl border border-blue-100 bg-white px-5 py-3 font-black text-[#05245c] transition hover:bg-blue-50"
              >
                Atualizar
              </button>
            </div>

            {itens.length === 0 ? (
              <div className="rounded-3xl border border-dashed border-blue-100 bg-[#f7fbff] p-8 text-center">
                <h3 className="text-2xl font-black text-[#071b3a]">
                  Nenhum item cadastrado
                </h3>

                <p className="mt-2 text-slate-600">
                  Cadastre produtos, serviços, locações ou assinaturas para exibir na página da empresa.
                </p>
              </div>
            ) : (
              <div className="grid gap-4">
                {itens.map((item) => (
                  <article
                    key={item.id}
                    className="rounded-3xl border border-blue-50 bg-[#f7fbff] p-4"
                  >
                    <div className="grid gap-4 md:grid-cols-[120px_1fr]">
                      <div className="h-32 overflow-hidden rounded-2xl bg-white">
                        {item.video_url ? (
                          <video
                            src={item.video_url}
                            className="h-full w-full object-cover"
                            muted
                            playsInline
                            controls
                          />
                        ) : item.imagem_url ? (
                          <img
                            src={item.imagem_url}
                            alt={item.nome}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="grid h-full place-items-center text-4xl">
                            🧩
                          </div>
                        )}
                      </div>

                      <div>
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <div className="flex flex-wrap gap-2">
                              <span className="rounded-full bg-white px-3 py-1 text-xs font-black text-[#05245c]">
                                {item.tipo || 'produto'}
                              </span>

                              <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-black text-blue-700">
                                {nomePrecificacao(item.precificacao)}
                              </span>

                              {item.destaque && (
                                <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700">
                                  Destaque
                                </span>
                              )}

                              <span
                                className={`rounded-full px-3 py-1 text-xs font-black ${
                                  item.ativo
                                    ? 'bg-blue-100 text-blue-700'
                                    : 'bg-red-100 text-red-700'
                                }`}
                              >
                                {item.ativo ? 'Ativo' : 'Inativo'}
                              </span>

                              {Array.isArray(item.image_urls) && item.image_urls.length > 1 && (
                                <span className="rounded-full bg-white px-3 py-1 text-xs font-black text-slate-600">
                                  {item.image_urls.length} fotos
                                </span>
                              )}

                              {item.video_url && (
                                <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700">
                                  vídeo 30s
                                </span>
                              )}
                            </div>

                            <h3 className="mt-3 text-xl font-black text-[#071b3a]">
                              {item.nome}
                            </h3>

                            <p className="mt-1 text-sm font-bold text-slate-500">
                              {item.categoria || 'Sem categoria'}
                            </p>
                          </div>

                          <p className="text-2xl font-black text-[#05245c]">
                            {item.precificacao === 'sob_consulta'
                              ? 'Sob consulta'
                              : formatarDinheiro(Number(item.preco || 0))}
                          </p>
                        </div>

                        {item.descricao && (
                          <p className="mt-3 text-sm leading-6 text-slate-600">
                            {item.descricao}
                          </p>
                        )}

                        <div className="mt-3 grid gap-2 rounded-2xl bg-white p-4 text-sm font-bold text-slate-600 sm:grid-cols-2">
                          <p>
                            Unidade: {item.unidade_label || item.unidade || 'unidade'}
                          </p>

                          <p>
                            Valor mínimo: {formatarDinheiro(Number(item.valor_minimo || 0))}
                          </p>

                          <p>
                            Campos: {[
                              item.permite_quantidade !== false ? 'quantidade' : '',
                              item.permite_largura ? 'largura' : '',
                              item.permite_altura ? 'altura' : '',
                              item.permite_comprimento ? 'comprimento' : '',
                            ].filter(Boolean).join(', ') || 'sem campos'}
                          </p>

                          <p>
                            Sinal: {item.cobrar_sinal_personalizado
                              ? `${item.percentual_sinal_produto || 0}%`
                              : 'padrão da empresa'}
                          </p>
                        </div>

                        <div className="mt-4 grid gap-2 sm:grid-cols-3">
                          <button
                            onClick={() => preencherEdicao(item)}
                            className="rounded-2xl border border-blue-100 bg-white px-4 py-3 font-black text-[#05245c] transition hover:bg-blue-50"
                          >
                            Editar
                          </button>

                          <button
                            onClick={() => alternarAtivo(item)}
                            className="rounded-2xl border border-blue-100 bg-white px-4 py-3 font-black text-[#05245c] transition hover:bg-blue-50"
                          >
                            {item.ativo ? 'Desativar' : 'Ativar'}
                          </button>

                          <button
                            onClick={() => excluirItem(item.id)}
                            className="rounded-2xl bg-red-50 px-4 py-3 font-black text-red-700 transition hover:bg-red-100"
                          >
                            Excluir
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
        </section>
      </section>
    </main>
  )
}
