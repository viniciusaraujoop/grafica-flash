import { createNotification } from '@/lib/orcaly-audit'
import { getWhatsAppSettings, money, sanitizePhone, sendWhatsAppMessage, shortId } from '@/lib/whatsapp'

type SupabaseAdmin = any

function siteUrl() {
  return (process.env.NEXT_PUBLIC_SITE_URL || 'https://orcaly.com.br').replace(/\/$/, '')
}

function orderUrl(order: any) {
  return order?.id ? `${siteUrl()}/painel/pedidos/${order.id}` : `${siteUrl()}/painel/pedidos`
}

function statusMessage(status: string, companyName: string, orderNumber: string) {
  const normalized = String(status || '').toLowerCase()

  if (normalized.includes('análise') || normalized.includes('analise')) {
    return `Seu pedido ${orderNumber} está em análise. A equipe da ${companyName} está conferindo os detalhes antes de seguir.`
  }

  if (normalized.includes('aprov')) {
    return `Seu pedido ${orderNumber} foi aprovado. A equipe da ${companyName} vai seguir para a próxima etapa.`
  }

  if (normalized.includes('produção') || normalized.includes('producao')) {
    return `Seu pedido ${orderNumber} entrou em produção. A equipe da ${companyName} já está trabalhando nele.`
  }

  if (normalized.includes('pronto')) {
    return `Seu pedido ${orderNumber} está pronto. A equipe da ${companyName} vai combinar retirada, entrega ou finalização.`
  }

  if (normalized.includes('entreg')) {
    return `Seu pedido ${orderNumber} foi marcado como entregue. Obrigado por comprar com ${companyName}.`
  }

  if (normalized.includes('cancel')) {
    return `Seu pedido ${orderNumber} foi cancelado. Se tiver dúvidas, fale com a equipe da ${companyName}.`
  }

  if (normalized.includes('pendente')) {
    return `Seu pedido ${orderNumber} está pendente. A equipe da ${companyName} pode precisar de alguma informação para continuar.`
  }

  return `Atualização do seu pedido ${orderNumber}: ${status}. Empresa: ${companyName}.`
}

async function safeSend(supabaseAdmin: SupabaseAdmin, options: any) {
  try {
    return await sendWhatsAppMessage(supabaseAdmin, options)
  } catch (error) {
    console.error('[Orçaly WhatsApp]', error)
    return { ok: false, error: error instanceof Error ? error.message : 'Erro ao enviar WhatsApp.' }
  }
}

async function safeUpdateOrder(supabaseAdmin: SupabaseAdmin, orderId: string | null | undefined, update: Record<string, any>) {
  if (!orderId) return

  try {
    await supabaseAdmin
      .from('orders')
      .update(update)
      .eq('id', orderId)
  } catch (error) {
    console.error('[Orçaly WhatsApp] Falha ao atualizar controle do pedido:', error)
  }
}

async function safeInternalNotification(
  supabaseAdmin: SupabaseAdmin,
  input: {
    companyId: string
    title: string
    message: string
    linkUrl?: string
    orderId?: string
    type?: string
  }
) {
  try {
    await createNotification(supabaseAdmin, {
      company_id: input.companyId,
      tipo: input.type || 'order',
      titulo: input.title,
      mensagem: input.message,
      link_url: input.linkUrl || undefined,
      payload: {
        order_id: input.orderId || null,
        origem: 'whatsapp_pedidos_status',
      },
    })
  } catch (error) {
    console.error('[Orçaly Notification] Falha ao criar notificação interna:', error)
  }
}

export async function notifyNewOrder(
  supabaseAdmin: SupabaseAdmin,
  payload: {
    company: any
    order: any
    cliente?: any
    total?: number
    resumo?: string
  }
) {
  const { company, order } = payload
  if (!company?.id || !order?.id) return { ok: false, skipped: true }

  const settings = await getWhatsAppSettings(supabaseAdmin, company.id)
  const numero = `#${shortId(order.id)}`
  const total = Number(payload.total || order.valor_total || order.preco_estimado || 0)
  const resumo = payload.resumo || order.itens_resumo || order.produto || 'Pedido'
  const companyName = company.nome || 'Empresa'
  const customerName = order.nome || payload.cliente?.nome || 'Cliente'
  const customerPhone = order.telefone || payload.cliente?.telefone || 'não informado'
  const link = orderUrl(order)

  await safeInternalNotification(supabaseAdmin, {
    companyId: company.id,
    title: 'Novo pedido recebido',
    message: `${customerName} enviou um pedido: ${resumo}. Valor: ${money(total)}.`,
    linkUrl: link,
    orderId: order.id,
  })

  await safeUpdateOrder(supabaseAdmin, order.id, {
    notificado_em: new Date().toISOString(),
  })

  if (!settings.enabled) {
    return { ok: true, whatsapp_skipped: true, reason: 'WhatsApp desativado nas configurações.' }
  }

  const results: any[] = []

  if (settings.notify_owner_new_order) {
    const to = sanitizePhone(settings.owner_phone || company.whatsapp)

    if (to) {
      const result = await safeSend(supabaseAdmin, {
        companyId: company.id,
        orderId: order.id,
        eventType: 'owner_new_order',
        to,
        text:
          `Novo pedido recebido no Orçaly.\n\n` +
          `Pedido: ${numero}\n` +
          `Cliente: ${customerName}\n` +
          `WhatsApp: ${customerPhone}\n` +
          `Itens: ${resumo}\n` +
          `Valor: ${money(total)}\n\n` +
          `Abrir pedido: ${link}`,
        templateName: settings.template_order_created,
        templateParams: [companyName, numero, customerName, money(total), link],
        templateLanguage: settings.template_language,
        phoneNumberId: settings.phone_number_id,
      })

      results.push({ target: 'owner', ...result })

      if (result?.ok) {
        await safeUpdateOrder(supabaseAdmin, order.id, {
          whatsapp_owner_notified_at: new Date().toISOString(),
        })
      }
    }
  }

  if (settings.notify_client_new_order) {
    const to = sanitizePhone(order.telefone || payload.cliente?.telefone)

    if (to) {
      const result = await safeSend(supabaseAdmin, {
        companyId: company.id,
        orderId: order.id,
        eventType: 'client_new_order',
        to,
        text:
          `Olá, ${customerName}!\n\n` +
          `Recebemos seu pedido ${numero} em ${companyName}.\n` +
          `Itens: ${resumo}\n` +
          `Valor estimado: ${money(total)}\n\n` +
          `Nossa equipe vai analisar e seguir com o atendimento.`,
        templateName: settings.template_order_created,
        templateParams: [customerName, numero, companyName, money(total)],
        templateLanguage: settings.template_language,
        phoneNumberId: settings.phone_number_id,
      })

      results.push({ target: 'client_created', ...result })

      if (result?.ok) {
        await safeUpdateOrder(supabaseAdmin, order.id, {
          whatsapp_client_created_notified_at: new Date().toISOString(),
        })
      }
    }
  }

  return { ok: true, results }
}

export async function notifyOrderStatus(
  supabaseAdmin: SupabaseAdmin,
  payload: {
    company: any
    order: any
    status: string
    source?: string
  }
) {
  const { company, order } = payload

  if (!company?.id || !order?.id || !payload.status) {
    return { ok: false, skipped: true }
  }

  const settings = await getWhatsAppSettings(supabaseAdmin, company.id)

  if (!settings.enabled || !settings.notify_client_order_status) {
    return { ok: true, whatsapp_skipped: true, reason: 'WhatsApp de status desativado.' }
  }

  const to = sanitizePhone(order.telefone || order.customer_whatsapp)

  if (!to) {
    return { ok: false, skipped: true, reason: 'Cliente sem WhatsApp/telefone.' }
  }

  const numero = `#${shortId(order.id)}`
  const companyName = company.nome || 'Empresa'
  const customerName = order.nome || order.customer_name || 'Cliente'
  const message = statusMessage(payload.status, companyName, numero)

  const result = await safeSend(supabaseAdmin, {
    companyId: company.id,
    orderId: order.id,
    eventType: `client_order_status_${payload.source || 'manual'}`,
    to,
    text:
      `Olá, ${customerName}!\n\n` +
      `${message}\n\n` +
      `Qualquer dúvida, responda esta mensagem.`,
    templateName: settings.template_order_status,
    templateParams: [customerName, numero, payload.status, companyName],
    templateLanguage: settings.template_language,
    phoneNumberId: settings.phone_number_id,
  })

  if (result?.ok) {
    await safeUpdateOrder(supabaseAdmin, order.id, {
      whatsapp_last_status_notified: payload.status,
      whatsapp_last_status_notified_at: new Date().toISOString(),
    })
  }

  return result
}

export async function notifyProposalAction(
  supabaseAdmin: SupabaseAdmin,
  payload: {
    company: any
    proposal: any
    event: 'sent' | 'approved' | 'change_requested' | 'rejected'
    note?: string | null
    pixValor?: number | null
  }
) {
  const { company, proposal } = payload
  if (!company?.id || !proposal?.id) return

  const settings = await getWhatsAppSettings(supabaseAdmin, company.id)
  if (!settings.enabled) return

  const numero = proposal.proposta_numero || `#${shortId(proposal.id)}`
  const valor = money(proposal.valor_total || 0)
  const label: Record<string, string> = {
    sent: 'Proposta enviada',
    approved: 'Proposta aprovada',
    change_requested: 'Alteração solicitada',
    rejected: 'Proposta recusada',
  }

  if (settings.notify_owner_proposal) {
    const to = sanitizePhone(settings.owner_phone || company.whatsapp)
    if (to) {
      await safeSend(supabaseAdmin, {
        companyId: company.id,
        orderId: proposal.order_id,
        proposalId: proposal.id,
        eventType: `owner_proposal_${payload.event}`,
        to,
        text: `${label[payload.event]} no Orçaly.\n\nProposta: ${numero}\nCliente: ${proposal.cliente_nome || 'Cliente'}\nValor: ${valor}${payload.note ? `\nObservação: ${payload.note}` : ''}`,
        templateName: settings.template_proposal_update,
        templateParams: [company.nome || 'Empresa', numero, label[payload.event], proposal.cliente_nome || 'Cliente', valor],
        templateLanguage: settings.template_language,
        phoneNumberId: settings.phone_number_id,
      })
    }
  }

  if (settings.notify_client_proposal) {
    const to = sanitizePhone(proposal.cliente_whatsapp)
    if (to) {
      await safeSend(supabaseAdmin, {
        companyId: company.id,
        orderId: proposal.order_id,
        proposalId: proposal.id,
        eventType: `client_proposal_${payload.event}`,
        to,
        text: `${label[payload.event]}: ${numero}\n\nValor: ${valor}\nEmpresa: ${company.nome || 'Empresa'}\n${proposal.token ? `${siteUrl()}/proposta/${proposal.token}` : ''}`,
        templateName: settings.template_proposal_update,
        templateParams: [proposal.cliente_nome || 'Cliente', numero, label[payload.event], valor, company.nome || 'Empresa'],
        templateLanguage: settings.template_language,
        phoneNumberId: settings.phone_number_id,
      })
    }
  }
}
