import { createClient } from '@supabase/supabase-js'
import { NextRequest } from 'next/server'

export type CurrentRole =
  | 'dono'
  | 'gerente'
  | 'atendente'
  | 'producao'
  | 'super_admin'
  | 'funcionario'

export function getSupabaseAdmin() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error('Variáveis do Supabase não configuradas no servidor.')
  }

  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  })
}

export function isUuid(value: unknown) {
  return typeof value === 'string'
    && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
}

export async function getRequester(request: NextRequest, supabaseAdmin: ReturnType<typeof getSupabaseAdmin>) {
  const token = (request.headers.get('authorization') || '').replace('Bearer ', '').trim()

  if (!token) return null

  const { data, error } = await supabaseAdmin.auth.getUser(token)

  if (error || !data.user) return null

  return data.user
}

export function assinaturaEstaAtiva(company: any | null) {
  if (!company) return false
  if (company.assinatura_status !== 'ativa') return false
  if (!company.assinatura_expira_em) return true
  return new Date(company.assinatura_expira_em) > new Date()
}

export function permissionsByRole(role: CurrentRole | null, isAdminMaster = false) {
  const r = String(role || '').toLowerCase()
  const isOwner = r === 'dono'
  const isManager = r === 'gerente'
  const isAttendant = r === 'atendente'
  const isProduction = r === 'producao'

  return {
    isOwner,
    isAdminMaster,
    canManage: isAdminMaster || isOwner || isManager,
    canFinance: isAdminMaster || isOwner || isManager,
    canConfig: isAdminMaster || isOwner,
    canProducts: isAdminMaster || isOwner || isManager || isProduction,
    canProposal: isAdminMaster || isOwner || isManager || isAttendant,
    canSubscription: isAdminMaster || isOwner || isManager,
    canProduction: isAdminMaster || isOwner || isManager || isProduction,
  }
}

export async function getCompanyAccess(
  supabaseAdmin: ReturnType<typeof getSupabaseAdmin>,
  userId: string,
  email?: string | null
) {
  const normalizedEmail = String(email || '').toLowerCase()
  const isAdminMaster = normalizedEmail === 'araujovinicius249@gmail.com'

  if (!isUuid(userId)) {
    return { company: null, role: null, ...permissionsByRole(null, isAdminMaster) }
  }

  const { data: ownerCompany, error: ownerError } = await supabaseAdmin
    .from('companies')
    .select('*')
    .or(`owner_id.eq.${userId},tester_id.eq.${userId}`)
    .limit(1)
    .maybeSingle()

  if (ownerError) throw ownerError

  if (ownerCompany?.id) {
    return {
      company: ownerCompany,
      role: isAdminMaster ? 'super_admin' : 'dono',
      ...permissionsByRole('dono', isAdminMaster),
    }
  }

  const { data: member, error: memberError } = await supabaseAdmin
    .from('company_members')
    .select('company_id,cargo,status')
    .eq('user_id', userId)
    .eq('status', 'ativo')
    .limit(1)
    .maybeSingle()

  if (memberError) throw memberError

  if (member?.company_id && isUuid(member.company_id)) {
    const { data: company, error: companyError } = await supabaseAdmin
      .from('companies')
      .select('*')
      .eq('id', member.company_id)
      .maybeSingle()

    if (companyError) throw companyError

    const role = (member.cargo || 'funcionario') as CurrentRole
    return { company, role, ...permissionsByRole(role, isAdminMaster) }
  }

  // Fallback importante para contas criadas manualmente/teste:
  // se a empresa já existe com o mesmo e-mail do usuário, vinculamos o owner_id
  // automaticamente e liberamos o acesso ao painel. Sem isso, o login cai em /cadastro
  // mesmo com a empresa cadastrada no banco. Coisa linda: o usuário existe, a empresa
  // existe, mas um UUID separando os dois resolve destruir a tarde.
  if (normalizedEmail) {
    const { data: emailCompany, error: emailCompanyError } = await supabaseAdmin
      .from('companies')
      .select('*')
      .eq('email', normalizedEmail)
      .limit(1)
      .maybeSingle()

    if (emailCompanyError) throw emailCompanyError

    if (emailCompany?.id) {
      const shouldAttachOwner = !emailCompany.owner_id

      if (shouldAttachOwner) {
        const { error: attachError } = await supabaseAdmin
          .from('companies')
          .update({ owner_id: userId, updated_at: new Date().toISOString() })
          .eq('id', emailCompany.id)

        if (attachError) throw attachError

        emailCompany.owner_id = userId
      }

      return {
        company: emailCompany,
        role: isAdminMaster ? 'super_admin' : 'dono',
        ...permissionsByRole('dono', isAdminMaster),
      }
    }
  }

  if (isAdminMaster) {
    const { data: adminCompany, error: adminCompanyError } = await supabaseAdmin
      .from('companies')
      .select('*')
      .eq('slug', 'grafica-flash')
      .maybeSingle()

    if (adminCompanyError) throw adminCompanyError

    if (adminCompany?.id) {
      return { company: adminCompany, role: 'super_admin', ...permissionsByRole('dono', true) }
    }
  }

  return { company: null, role: null, ...permissionsByRole(null, isAdminMaster) }
}
