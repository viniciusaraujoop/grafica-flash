'use client'

import { FormEvent, useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

type OptionValue = {
  id: string
  nome: string
  ajuste_tipo: 'fixo' | 'percentual'
  ajuste_valor: number
}

type OptionGroup = {
  id: string
  nome: string
  obrigatorio: boolean
  tipo: 'unico'
  valores: OptionValue[]
}

type ProductDraft = {
  id?: string
  nome: string
  descricao: string
  categoria: string
  tipo: string
  preco: string
  unidade: string
  unidade_label: string
  ativo: boolean
  destaque: boolean
  precificacao: string
  permite_largura: boolean
  permite_altura: boolean
  permite_comprimento: boolean
  permite_quantidade: boolean
  valor_minimo: string
  prazo_medio: string
  image_urls: string[]
  perguntas: string
  opcoes: OptionGroup[]
}

function uid() {
  return Math.random().toString(36).slice(2, 10)
}

function money(value: any) {
  return Number(String(value || 0).replace(',', '.')) || 0
}

function moeda(value: number) {
  return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

function emptyDraft(): ProductDraft {
  return {
    nome: '',
    descricao: '',
    categoria: 'Geral',
    tipo: 'produto',
    preco: '',
    unidade: 'unidade',
    unidade_label: 'unidade',
    ativo: true,
    destaque: false,
    precificacao: 'unidade',
    permite_largura: false,
    permite_altura: false,
    permite_comprimento: false,
    permite_quantidade: true,
    valor_minimo: '',
    prazo_medio: '',
    image_urls: [],
    perguntas: '',
    opcoes: [],
  }
}

const exemplosPorSegmento: Record<string, OptionGroup[]> = {
  grafica: [
    {
      id: uid(),
      nome: 'Tipo de papel/material',
      obrigatorio: true,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'Couchê 90g', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'Couchê 150g', ajuste_tipo: 'fixo', ajuste_valor: 8 },
        { id: uid(), nome: 'Adesivo vinil', ajuste_tipo: 'fixo', ajuste_valor: 15 },
      ],
    },
    {
      id: uid(),
      nome: 'Acabamento',
      obrigatorio: false,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'Sem acabamento', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'Laminação fosca', ajuste_tipo: 'percentual', ajuste_valor: 15 },
        { id: uid(), nome: 'Corte especial', ajuste_tipo: 'fixo', ajuste_valor: 20 },
      ],
    },
  ],
  moda_varejo: [
    {
      id: uid(),
      nome: 'Tecido',
      obrigatorio: true,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'Algodão', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'Linho', ajuste_tipo: 'fixo', ajuste_valor: 25 },
        { id: uid(), nome: 'Moletom premium', ajuste_tipo: 'fixo', ajuste_valor: 35 },
      ],
    },
    {
      id: uid(),
      nome: 'Tamanho',
      obrigatorio: true,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'P', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'M', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'G', ajuste_tipo: 'fixo', ajuste_valor: 5 },
        { id: uid(), nome: 'GG', ajuste_tipo: 'fixo', ajuste_valor: 8 },
      ],
    },
  ],
  alimenticio: [
    {
      id: uid(),
      nome: 'Sabor',
      obrigatorio: true,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'Chocolate', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'Ninho com Nutella', ajuste_tipo: 'fixo', ajuste_valor: 18 },
        { id: uid(), nome: 'Red Velvet', ajuste_tipo: 'fixo', ajuste_valor: 22 },
      ],
    },
    {
      id: uid(),
      nome: 'Tipo de massa',
      obrigatorio: true,
      tipo: 'unico',
      valores: [
        { id: uid(), nome: 'Tradicional', ajuste_tipo: 'fixo', ajuste_valor: 0 },
        { id: uid(), nome: 'Sem lactose', ajuste_tipo: 'percentual', ajuste_valor: 12 },
        { id: uid(), nome: 'Integral', ajuste_tipo: 'fixo', ajuste_valor: 10 },
      ],
    },
  ],
}

export default function CatalogoPage() {
  const [company, setCompany] = useState<any>(null)
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [erro, setErro] = useState('')
  const [message, setMessage] = useState('')
  const [tab, setTab] = useState<'produtos' | 'produto' | 'loja'>('produtos')
  const [draft, setDraft] = useState<ProductDraft>(emptyDraft())
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('Todos')
  const fileRef = useRef<HTMLInputElement | null>(null)

  const [settings, setSettings] = useState({
    marketplace_ativo: true,
    marketplace_titulo: '',
    marketplace_subtitulo: '',
    marketplace_banner_url: '',
    marketplace_texto_botao: 'Comprar agora',
    marketplace_sobre: '',
    marketplace_endereco: '',
    marketplace_mapa_url: '',
    marketplace_termos: '',
    atendimento_horario: '',
    atendimento_observacao: '',
    instagram: '',
  })

  async function carregarEmpresa(userId: string) {
    const { data: ownCompany, error: ownError } = await supabase
      .from('companies')
      .select('*')
      .or(`owner_id.eq.${userId},tester_id.eq.${userId}`)
      .maybeSingle()

    if (ownError) throw ownError
    if (ownCompany) return ownCompany

    const { data: member, error: memberError } = await supabase
      .from('company_members')
      .select('company_id,cargo')
      .eq('user_id', userId)
      .eq('status', 'ativo')
      .maybeSingle()

    if (memberError) throw memberError
    if (!member?.company_id) return null

    const { data: memberCompany, error: companyError } = await supabase
      .from('companies')
      .select('*')
      .eq('id', member.company_id)
      .maybeSingle()

    if (companyError) throw companyError
    return memberCompany
  }

  async function carregar() {
    setLoading(true)
    setErro('')

    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const user = sessionData.session?.user

      if (!user) {
        window.location.href = '/login'
        return
      }

      const empresa = await carregarEmpresa(user.id)

      if (!empresa) {
        setErro('Empresa não encontrada.')
        setLoading(false)
        return
      }

      setCompany(empresa)
      setSettings({
        marketplace_ativo: empresa.marketplace_ativo !== false,
        marketplace_titulo: empresa.marketplace_titulo || '',
        marketplace_subtitulo: empresa.marketplace_subtitulo || '',
        marketplace_banner_url: empresa.marketplace_banner_url || '',
        marketplace_texto_botao: empresa.marketplace_texto_botao || 'Comprar agora',
        marketplace_sobre: empresa.marketplace_sobre || '',
        marketplace_endereco: empresa.marketplace_endereco || '',
        marketplace_mapa_url: empresa.marketplace_mapa_url || '',
        marketplace_termos: empresa.marketplace_termos || '',
        atendimento_horario: empresa.atendimento_horario || '',
        atendimento_observacao: empresa.atendimento_observacao || '',
        instagram: empresa.instagram || '',
      })

      const { data: productData, error: productError } = await supabase
        .from('products')
        .select('*')
        .eq('company_id', empresa.id)
        .eq('arquivado', false)
        .order('created_at', { ascending: false })

      if (productError) throw productError

      setProducts(productData || [])
    } catch (error) {
      setErro(error instanceof Error ? error.message : 'Erro ao carregar catálogo.')
    }

    setLoading(false)
  }

  useEffect(() => {
    carregar()
  }, [])

  const categories = useMemo(() => {
    return ['Todos', ...Array.from(new Set(products.map((p) => p.categoria || 'Geral')))]
  }, [products])

  const filteredProducts = useMemo(() => {
    let list = [...products]

    if (category !== 'Todos') list = list.filter((p) => (p.categoria || 'Geral') === category)

    const q = search.trim().toLowerCase()
    if (q) {
      list = list.filter((p) =>
        String(p.nome || '').toLowerCase().includes(q) ||
        String(p.descricao || '').toLowerCase().includes(q) ||
        String(p.categoria || '').toLowerCase().includes(q)
      )
    }

    return list
  }, [products, category, search])

  function updateDraft(field: keyof ProductDraft, value: any) {
    setDraft((current) => ({ ...current, [field]: value }))
  }

  function startNewProduct() {
    setDraft(emptyDraft())
    setTab('produto')
  }

  function editProduct(product: any) {
    const config = product.configuracoes || {}
    const perguntas = Array.isArray(config.perguntas) ? config.perguntas.join('\n') : ''
    const opcoes = Array.isArray(config.opcoes) ? config.opcoes : []

    setDraft({
      id: product.id,
      nome: product.nome || '',
      descricao: product.descricao || '',
      categoria: product.categoria || 'Geral',
      tipo: product.tipo || 'produto',
      preco: String(product.preco || ''),
      unidade: product.unidade || 'unidade',
      unidade_label: product.unidade_label || product.unidade || 'unidade',
      ativo: product.ativo !== false,
      destaque: Boolean(product.destaque),
      precificacao: product.precificacao || 'unidade',
      permite_largura: Boolean(product.permite_largura),
      permite_altura: Boolean(product.permite_altura),
      permite_comprimento: Boolean(product.permite_comprimento),
      permite_quantidade: product.permite_quantidade !== false,
      valor_minimo: String(product.valor_minimo || ''),
      prazo_medio: product.prazo_medio || '',
      image_urls: Array.isArray(product.image_urls) ? product.image_urls.slice(0, 4) : product.imagem_url ? [product.imagem_url] : [],
      perguntas,
      opcoes,
    })

    setTab('produto')
  }

  async function uploadImage(file: File) {
    if (!company) return

    if (draft.image_urls.length >= 4) {
      setErro('Você pode adicionar até 4 fotos por produto/serviço.')
      return
    }

    const ext = file.name.split('.').pop() || 'jpg'
    const path = `${company.id}/produtos/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`

    const { error } = await supabase.storage
      .from('produtos')
      .upload(path, file, { upsert: false })

    if (error) {
      setErro(error.message)
      return
    }

    const { data } = supabase.storage.from('produtos').getPublicUrl(path)

    setDraft((current) => ({
      ...current,
      image_urls: [...current.image_urls, data.publicUrl].slice(0, 4),
    }))
  }

  function removeImage(index: number) {
    setDraft((current) => ({
      ...current,
      image_urls: current.image_urls.filter((_, i) => i !== index),
    }))
  }

  function addOptionGroup() {
    setDraft((current) => ({
      ...current,
      opcoes: [
        ...current.opcoes,
        {
          id: uid(),
          nome: 'Nova variação',
          obrigatorio: true,
          tipo: 'unico',
          valores: [
            { id: uid(), nome: 'Opção padrão', ajuste_tipo: 'fixo', ajuste_valor: 0 },
          ],
        },
      ],
    }))
  }

  function applyExampleOptions() {
    const modelo = company?.modelo_negocio || 'outros'
    const exemplos = exemplosPorSegmento[modelo] || exemplosPorSegmento.grafica

    setDraft((current) => ({
      ...current,
      opcoes: exemplos,
    }))
  }

  function updateOptionGroup(index: number, field: keyof OptionGroup, value: any) {
    setDraft((current) => ({
      ...current,
      opcoes: current.opcoes.map((group, i) => i === index ? { ...group, [field]: value } : group),
    }))
  }

  function removeOptionGroup(index: number) {
    setDraft((current) => ({
      ...current,
      opcoes: current.opcoes.filter((_, i) => i !== index),
    }))
  }

  function addOptionValue(groupIndex: number) {
    setDraft((current) => ({
      ...current,
      opcoes: current.opcoes.map((group, i) => i === groupIndex
        ? {
            ...group,
            valores: [...group.valores, { id: uid(), nome: 'Nova opção', ajuste_tipo: 'fixo', ajuste_valor: 0 }],
          }
        : group
      ),
    }))
  }

  function updateOptionValue(groupIndex: number, valueIndex: number, field: keyof OptionValue, value: any) {
    setDraft((current) => ({
      ...current,
      opcoes: current.opcoes.map((group, i) => i === groupIndex
        ? {
            ...group,
            valores: group.valores.map((option, j) => j === valueIndex ? { ...option, [field]: value } : option),
          }
        : group
      ),
    }))
  }

  function removeOptionValue(groupIndex: number, valueIndex: number) {
    setDraft((current) => ({
      ...current,
      opcoes: current.opcoes.map((group, i) => i === groupIndex
        ? { ...group, valores: group.valores.filter((_, j) => j !== valueIndex) }
        : group
      ),
    }))
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!company) return
    if (!draft.nome.trim()) {
      setErro('Informe o nome do produto/serviço.')
      return
    }

    setSaving(true)
    setErro('')
    setMessage('')

    const perguntas = draft.perguntas
      .split('\n')
      .map((item) => item.trim())
      .filter(Boolean)

    const payload = {
      company_id: company.id,
      nome: draft.nome.trim(),
      descricao: draft.descricao.trim() || null,
      categoria: draft.categoria.trim() || 'Geral',
      tipo: draft.tipo,
      preco: money(draft.preco),
      unidade: draft.unidade,
      unidade_label: draft.unidade_label,
      ativo: draft.ativo,
      destaque: draft.destaque,
      precificacao: draft.precificacao,
      permite_largura: draft.permite_largura,
      permite_altura: draft.permite_altura,
      permite_comprimento: draft.permite_comprimento,
      permite_quantidade: draft.permite_quantidade,
      valor_minimo: money(draft.valor_minimo),
      prazo_medio: draft.prazo_medio || null,
      imagem_url: draft.image_urls[0] || null,
      image_urls: draft.image_urls,
      configuracoes: {
        perguntas,
        opcoes: draft.opcoes,
      },
    }

    const request = draft.id
      ? supabase.from('products').update(payload).eq('id', draft.id)
      : supabase.from('products').insert(payload)

    const { error } = await request

    if (error) {
      setErro(error.message)
    } else {
      setMessage('Produto salvo e sincronizado com a loja.')
      setDraft(emptyDraft())
      setTab('produtos')
      await carregar()
    }

    setSaving(false)
  }

  async function deleteProduct(id: string) {
    if (!company) return

    const ok = window.confirm('Remover este produto/serviço do catálogo? O histórico de pedidos será preservado.')
    if (!ok) return

    const { error } = await supabase
      .from('products')
      .update({
        ativo: false,
        arquivado: true,
        deleted_at: new Date().toISOString(),
      })
      .eq('id', id)
      .eq('company_id', company.id)

    if (error) setErro(error.message)
    else {
      setProducts((current) => current.filter((product) => product.id !== id))
      setMessage('Produto removido do catálogo.')
    }
  }

  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!company) return

    setSaving(true)
    setErro('')
    setMessage('')

    const { error } = await supabase
      .from('companies')
      .update(settings)
      .eq('id', company.id)

    if (error) {
      setErro(error.message)
    } else {
      setMessage('Página da loja atualizada.')
      await carregar()
    }

    setSaving(false)
  }

  const lojaUrl = company ? `/site/${company.slug}` : '#'

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f8ff]">
        <div className="rounded-[2rem] bg-white p-8 font-black shadow-xl">Carregando catálogo...</div>
      </main>
    )
  }

  if (erro && !company) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f8ff] px-4">
        <div className="max-w-xl rounded-[2rem] bg-white p-8 text-center shadow-xl">
          <h1 className="text-3xl font-black text-[#071b3a]">Catálogo indisponível</h1>
          <p className="mt-3 font-bold text-red-600">{erro}</p>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#f5f8ff] px-4 py-6 text-[#071b3a]">
      <section className="mx-auto max-w-7xl">
        <header className="mb-6 overflow-hidden rounded-[2.5rem] border border-blue-100 bg-white shadow-2xl shadow-blue-950/8">
          <div className="relative p-6 sm:p-8">
            <div className="absolute right-0 top-0 h-48 w-48 rounded-full bg-blue-100 blur-3xl" />
            <div className="absolute bottom-0 right-36 h-48 w-48 rounded-full bg-emerald-100 blur-3xl" />

            <div className="relative flex flex-col gap-6 xl:flex-row xl:items-center xl:justify-between">
              <div>
                <Link href="/painel" className="text-sm font-black text-[#05245c]">← Voltar ao painel</Link>
                <h1 className="mt-4 text-4xl font-black tracking-[-0.05em] text-[#071b3a] sm:text-5xl">
                  Catálogo e loja
                </h1>
                <p className="mt-3 max-w-2xl font-bold leading-7 text-slate-500">
                  Produtos, serviços, variações, opcionais, fotos e aparência da página de vendas.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 xl:min-w-[420px]">
                <a href={lojaUrl} target="_blank" rel="noreferrer" className="rounded-2xl bg-[#05245c] px-5 py-4 text-center font-black text-white">
                  Abrir loja
                </a>
                <button onClick={startNewProduct} className="rounded-2xl border border-blue-100 bg-blue-50 px-5 py-4 font-black text-[#05245c]">
                  Novo item
                </button>
              </div>
            </div>
          </div>
        </header>

        {message && <div className="mb-5 rounded-2xl border border-emerald-100 bg-emerald-50 p-4 font-bold text-emerald-700">{message}</div>}
        {erro && <div className="mb-5 rounded-2xl border border-red-100 bg-red-50 p-4 font-bold text-red-700">{erro}</div>}

        <div className="mb-5 flex gap-2 overflow-x-auto rounded-[1.5rem] border border-blue-100 bg-white p-2 shadow-lg shadow-blue-950/5">
          {[
            ['produtos', 'Produtos e serviços'],
            ['produto', draft.id ? 'Editar item' : 'Novo item'],
            ['loja', 'Página da loja'],
          ].map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id as any)}
              className={`whitespace-nowrap rounded-2xl px-5 py-3 text-sm font-black transition ${
                tab === id ? 'bg-[#05245c] text-white shadow-lg shadow-[#05245c]/20' : 'text-slate-500 hover:bg-blue-50 hover:text-[#05245c]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === 'produtos' && (
          <section className="grid gap-5 xl:grid-cols-[260px_1fr]">
            <aside className="h-fit rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
              <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Filtros</p>

              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar item"
                className="mt-4 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 font-bold outline-none"
              />

              <div className="mt-4 grid gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`rounded-2xl px-4 py-3 text-left text-sm font-black ${
                      category === cat ? 'bg-[#05245c] text-white' : 'bg-[#f5f8ff] text-slate-600'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </aside>

            <div>
              <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Catálogo</p>
                  <h2 className="mt-1 text-3xl font-black tracking-[-0.04em] text-[#071b3a]">{filteredProducts.length} itens</h2>
                </div>
                <button onClick={startNewProduct} className="rounded-2xl bg-[#05245c] px-5 py-4 font-black text-white">Adicionar produto/serviço</button>
              </div>

              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {filteredProducts.map((product) => {
                  const options = product.configuracoes?.opcoes || []
                  const images = Array.isArray(product.image_urls) ? product.image_urls : product.imagem_url ? [product.imagem_url] : []

                  return (
                    <article key={product.id} className="overflow-hidden rounded-[2rem] border border-blue-100 bg-white shadow-xl shadow-blue-950/5">
                      <div className="aspect-[4/3] bg-[#f5f8ff]">
                        {images[0] ? (
                          <img src={images[0]} alt={product.nome} className="h-full w-full object-cover" />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-5xl font-black text-blue-100">
                            {String(product.nome || 'I').slice(0, 1)}
                          </div>
                        )}
                      </div>

                      <div className="p-5">
                        <div className="flex flex-wrap gap-2">
                          <span className={`rounded-full px-3 py-1 text-xs font-black ${product.ativo ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                            {product.ativo ? 'ativo' : 'inativo'}
                          </span>
                          {product.destaque && <span className="rounded-full bg-yellow-100 px-3 py-1 text-xs font-black text-yellow-700">destaque</span>}
                          <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-[#05245c]">{product.categoria || 'Geral'}</span>
                        </div>

                        <h3 className="mt-3 text-xl font-black text-[#071b3a]">{product.nome}</h3>
                        <p className="mt-2 line-clamp-2 text-sm font-bold leading-6 text-slate-500">{product.descricao || 'Sem descrição.'}</p>

                        <div className="mt-4 flex items-end justify-between gap-3">
                          <div>
                            <p className="text-xs font-bold text-slate-400">Preço base</p>
                            <p className="text-2xl font-black text-[#05245c]">{moeda(product.preco)}</p>
                          </div>
                          <p className="text-xs font-black text-slate-400">{options.length} variação(ões)</p>
                        </div>

                        <div className="mt-5 grid grid-cols-2 gap-2">
                          <button onClick={() => editProduct(product)} className="rounded-2xl bg-[#05245c] px-4 py-3 text-sm font-black text-white">Editar</button>
                          <button onClick={() => deleteProduct(product.id)} className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-black text-red-700">Remover</button>
                        </div>
                      </div>
                    </article>
                  )
                })}
              </div>

              {filteredProducts.length === 0 && (
                <div className="rounded-[2rem] border border-dashed border-slate-300 bg-white p-10 text-center">
                  <p className="text-2xl font-black text-[#071b3a]">Nenhum item encontrado</p>
                  <p className="mt-2 font-bold text-slate-500">Adicione produtos/serviços para aparecerem na loja.</p>
                </div>
              )}
            </div>
          </section>
        )}

        {tab === 'produto' && (
          <form onSubmit={saveProduct} className="grid gap-5 xl:grid-cols-[1fr_420px]">
            <section className="rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
              <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Item da loja</p>
              <h2 className="mt-1 text-3xl font-black tracking-[-0.04em]">{draft.id ? 'Editar produto/serviço' : 'Novo produto/serviço'}</h2>

              <div className="mt-6 grid gap-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Nome</span>
                    <input value={draft.nome} onChange={(e) => updateDraft('nome', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Categoria</span>
                    <input value={draft.categoria} onChange={(e) => updateDraft('categoria', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                </div>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Descrição</span>
                  <textarea value={draft.descricao} onChange={(e) => updateDraft('descricao', e.target.value)} rows={4} className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <div className="grid gap-4 sm:grid-cols-3">
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Preço base</span>
                    <input value={draft.preco} onChange={(e) => updateDraft('preco', e.target.value)} placeholder="0,00" className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Precificação</span>
                    <select value={draft.precificacao} onChange={(e) => updateDraft('precificacao', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none">
                      <option value="unidade">Por unidade</option>
                      <option value="m2">Por m²</option>
                      <option value="metro_linear">Metro linear</option>
                    </select>
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Valor mínimo</span>
                    <input value={draft.valor_minimo} onChange={(e) => updateDraft('valor_minimo', e.target.value)} placeholder="Opcional" className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Tipo</span>
                    <select value={draft.tipo} onChange={(e) => updateDraft('tipo', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none">
                      <option value="produto">Produto</option>
                      <option value="servico">Serviço</option>
                    </select>
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Unidade interna</span>
                    <input value={draft.unidade} onChange={(e) => updateDraft('unidade', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Texto da unidade na loja</span>
                    <input value={draft.unidade_label} onChange={(e) => updateDraft('unidade_label', e.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                  {[
                    ['ativo', 'Ativo'],
                    ['destaque', 'Destaque'],
                    ['permite_quantidade', 'Quantidade'],
                    ['permite_largura', 'Largura'],
                    ['permite_altura', 'Altura'],
                    ['permite_comprimento', 'Comprimento'],
                  ].map(([field, label]) => (
                    <label key={field} className="flex items-center gap-3 rounded-2xl bg-[#f5f8ff] p-4 font-black text-slate-700">
                      <input type="checkbox" checked={Boolean((draft as any)[field])} onChange={(e) => updateDraft(field as any, e.target.checked)} />
                      {label}
                    </label>
                  ))}
                </div>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Perguntas específicas deste item, uma por linha</span>
                  <textarea value={draft.perguntas} onChange={(e) => updateDraft('perguntas', e.target.value)} rows={4} placeholder={'Ex.: Qual cor?\nQual tamanho?\nTem referência?'} className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>
              </div>
            </section>

            <aside className="grid gap-5">
              <section className="rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
                <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Fotos</p>
                <h3 className="mt-1 text-2xl font-black">Até 4 imagens</h3>

                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => uploadImage(e.target.files?.[0] as File)} />

                <div className="mt-4 grid grid-cols-2 gap-3">
                  {draft.image_urls.map((url, index) => (
                    <div key={url} className="relative aspect-square overflow-hidden rounded-2xl bg-[#f5f8ff]">
                      <img src={url} alt={`Imagem ${index + 1}`} className="h-full w-full object-cover" />
                      <button type="button" onClick={() => removeImage(index)} className="absolute right-2 top-2 rounded-xl bg-red-600 px-2 py-1 text-xs font-black text-white">X</button>
                    </div>
                  ))}

                  {draft.image_urls.length < 4 && (
                    <button type="button" onClick={() => fileRef.current?.click()} className="aspect-square rounded-2xl border border-dashed border-blue-200 bg-[#f5f8ff] font-black text-[#05245c]">
                      + Foto
                    </button>
                  )}
                </div>
              </section>

              <section className="rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Variações</p>
                    <h3 className="mt-1 text-2xl font-black">Opcionais e materiais</h3>
                  </div>
                  <button type="button" onClick={applyExampleOptions} className="rounded-xl bg-blue-50 px-3 py-2 text-xs font-black text-[#05245c]">Modelo</button>
                </div>

                <div className="mt-4 grid gap-4">
                  {draft.opcoes.map((group, groupIndex) => (
                    <div key={group.id} className="rounded-2xl bg-[#f5f8ff] p-4">
                      <div className="grid gap-3">
                        <input value={group.nome} onChange={(e) => updateOptionGroup(groupIndex, 'nome', e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-3 font-bold outline-none" />

                        <label className="flex items-center gap-3 text-sm font-black text-slate-700">
                          <input type="checkbox" checked={group.obrigatorio} onChange={(e) => updateOptionGroup(groupIndex, 'obrigatorio', e.target.checked)} />
                          Obrigatório na loja
                        </label>

                        {group.valores.map((option, optionIndex) => (
                          <div key={option.id} className="grid gap-2 rounded-xl bg-white p-3">
                            <input value={option.nome} onChange={(e) => updateOptionValue(groupIndex, optionIndex, 'nome', e.target.value)} placeholder="Nome da opção" className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold outline-none" />
                            <div className="grid grid-cols-[1fr_1fr_auto] gap-2">
                              <select value={option.ajuste_tipo} onChange={(e) => updateOptionValue(groupIndex, optionIndex, 'ajuste_tipo', e.target.value)} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold outline-none">
                                <option value="fixo">R$ fixo</option>
                                <option value="percentual">% percentual</option>
                              </select>
                              <input value={option.ajuste_valor} onChange={(e) => updateOptionValue(groupIndex, optionIndex, 'ajuste_valor', money(e.target.value))} placeholder="Ajuste" className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold outline-none" />
                              <button type="button" onClick={() => removeOptionValue(groupIndex, optionIndex)} className="rounded-xl bg-red-50 px-3 py-2 text-xs font-black text-red-700">X</button>
                            </div>
                          </div>
                        ))}

                        <div className="grid grid-cols-2 gap-2">
                          <button type="button" onClick={() => addOptionValue(groupIndex)} className="rounded-xl bg-white px-3 py-2 text-sm font-black text-[#05245c]">+ Opção</button>
                          <button type="button" onClick={() => removeOptionGroup(groupIndex)} className="rounded-xl bg-red-50 px-3 py-2 text-sm font-black text-red-700">Remover grupo</button>
                        </div>
                      </div>
                    </div>
                  ))}

                  <button type="button" onClick={addOptionGroup} className="rounded-2xl border border-dashed border-blue-200 bg-blue-50 px-4 py-4 font-black text-[#05245c]">
                    + Adicionar grupo de opções
                  </button>
                </div>
              </section>

              <button disabled={saving} className="rounded-2xl bg-[#05245c] px-5 py-5 font-black text-white disabled:opacity-60">
                {saving ? 'Salvando...' : 'Salvar e publicar na loja'}
              </button>
            </aside>
          </form>
        )}

        {tab === 'loja' && (
          <form onSubmit={saveSettings} className="grid gap-5 xl:grid-cols-[1fr_420px]">
            <section className="rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
              <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Página pública</p>
              <h2 className="mt-1 text-3xl font-black tracking-[-0.04em]">Configuração da loja</h2>

              <div className="mt-6 grid gap-4">
                <label className="flex items-center gap-3 rounded-2xl bg-[#f5f8ff] p-4 font-black text-slate-700">
                  <input type="checkbox" checked={settings.marketplace_ativo} onChange={(e) => setSettings((v) => ({ ...v, marketplace_ativo: e.target.checked }))} />
                  Loja ativa no site público
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Título da loja</span>
                  <input value={settings.marketplace_titulo} onChange={(e) => setSettings((v) => ({ ...v, marketplace_titulo: e.target.value }))} placeholder="Ex.: Escolha seu pedido" className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Subtítulo</span>
                  <textarea value={settings.marketplace_subtitulo} onChange={(e) => setSettings((v) => ({ ...v, marketplace_subtitulo: e.target.value }))} rows={3} className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Texto do botão</span>
                  <input value={settings.marketplace_texto_botao} onChange={(e) => setSettings((v) => ({ ...v, marketplace_texto_botao: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Imagem/banner da loja</span>
                  <input value={settings.marketplace_banner_url} onChange={(e) => setSettings((v) => ({ ...v, marketplace_banner_url: e.target.value }))} placeholder="URL da imagem" className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Sobre a empresa</span>
                  <textarea value={settings.marketplace_sobre} onChange={(e) => setSettings((v) => ({ ...v, marketplace_sobre: e.target.value }))} rows={5} className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Instagram</span>
                    <input value={settings.instagram} onChange={(e) => setSettings((v) => ({ ...v, instagram: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                  <label className="grid gap-2">
                    <span className="text-sm font-black text-slate-700">Horário</span>
                    <input value={settings.atendimento_horario} onChange={(e) => setSettings((v) => ({ ...v, atendimento_horario: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                  </label>
                </div>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Endereço/localização</span>
                  <input value={settings.marketplace_endereco} onChange={(e) => setSettings((v) => ({ ...v, marketplace_endereco: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Link do Google Maps</span>
                  <input value={settings.marketplace_mapa_url} onChange={(e) => setSettings((v) => ({ ...v, marketplace_mapa_url: e.target.value }))} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>

                <label className="grid gap-2">
                  <span className="text-sm font-black text-slate-700">Termos/observações da loja</span>
                  <textarea value={settings.marketplace_termos} onChange={(e) => setSettings((v) => ({ ...v, marketplace_termos: e.target.value }))} rows={4} className="resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 font-bold outline-none" />
                </label>
              </div>
            </section>

            <aside className="grid gap-5">
              <section className="rounded-[2rem] border border-blue-100 bg-white p-5 shadow-xl shadow-blue-950/5">
                <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">Prévia</p>
                <h3 className="mt-1 text-2xl font-black">{settings.marketplace_titulo || `Loja ${company?.nome}`}</h3>
                <p className="mt-3 font-bold leading-7 text-slate-500">{settings.marketplace_subtitulo || 'Texto de apresentação da loja.'}</p>

                {settings.marketplace_banner_url && (
                  <img src={settings.marketplace_banner_url} alt="Banner" className="mt-4 aspect-video w-full rounded-2xl object-cover" />
                )}

                <div className="mt-4 grid gap-3">
                  <div className="rounded-2xl bg-[#f5f8ff] p-4">
                    <p className="font-black">Instagram</p>
                    <p className="text-sm font-bold text-slate-500">{settings.instagram || 'Não informado'}</p>
                  </div>
                  <div className="rounded-2xl bg-[#f5f8ff] p-4">
                    <p className="font-black">Endereço</p>
                    <p className="text-sm font-bold text-slate-500">{settings.marketplace_endereco || 'Não informado'}</p>
                  </div>
                </div>
              </section>

              <button disabled={saving} className="rounded-2xl bg-[#05245c] px-5 py-5 font-black text-white disabled:opacity-60">
                {saving ? 'Salvando...' : 'Salvar página da loja'}
              </button>
            </aside>
          </form>
        )}
      </section>
    </main>
  )
}
