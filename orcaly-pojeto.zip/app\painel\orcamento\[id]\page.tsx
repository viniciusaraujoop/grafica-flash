'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

type Empresa = {
  id: string
  nome: string
  slug: string | null
  whatsapp: string | null
  cor_principal: string | null
  logo_url: string | null
}

type Pedido = {
  id: string
  company_id: string | null
  nome: string
  telefone: string
  produto: string
  quantidade: number | null
  observacoes: string | null
  status: string | null
  preco_estimado: number | null
  valor_total: number | null
  valor_sinal: number | null
  percentual_sinal: number | null
  forma_pagamento: string | null
  parcelas: number | null
  itens_resumo: string | null
  arquivo_url: string | null
  created_at: string
}

type ItemPedido = {
  id: string
  nome: string
  tipo: string | null
  unidade: string | null
  quantidade: number | null
  preco_unitario: number | null
  subtotal: number | null
  largura: number | null
  altura: number | null
  comprimento: number | null
  area_m2: number | null
  precificacao: string | null
  detalhes_calculo: string | null
}

const statusOpcoes = [
  'Recebido',
  'Em análise',
  'Orçamento enviado',
  'Aguardando pagamento',
  'Em produção',
  'Finalizado',
  'Cancelado',
]

function formatarDinheiro(valor: number) {
  return Number(valor || 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  })
}

function formatarData(data: string) {
  if (!data) return 'Data não informada'

  return new Date(data).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function montarWhatsapp(telefone: string) {
  const numeros = String(telefone || '').replace(/\D/g, '')

  if (!numeros) return ''
  if (numeros.startsWith('55')) return numeros
  if (numeros.length >= 10) return `55${numeros}`

  return numeros
}

function getValorPedido(pedido: Pedido | null) {
  if (!pedido) return 0

  return Number(pedido.valor_total || pedido.preco_estimado || 0)
}

export default function OrcamentoPedidoPage() {
  const params = useParams()
  const pedidoId = String(params?.id || '')

  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [pedido, setPedido] = useState<Pedido | null>(null)
  const [itens, setItens] = useState<ItemPedido[]>([])
  const [carregando, setCarregando] = useState(true)
  const [mensagem, setMensagem] = useState('')

  async function carregarOrcamento() {
    setCarregando(true)
    setMensagem('')

    try {
      if (!pedidoId || pedidoId === 'undefined' || pedidoId === 'null') {
        setMensagem('Pedido não informado na URL.')
        return
      }

      const { data: pedidoData, error: pedidoError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', pedidoId)
        .maybeSingle()

      if (pedidoError) {
        setMensagem(`Erro ao buscar pedido: ${pedidoError.message}`)
        return
      }

      if (!pedidoData) {
        setMensagem('Pedido não encontrado. Volte ao painel e tente abrir novamente.')
        return
      }

      const pedidoEncontrado = pedidoData as Pedido
      setPedido(pedidoEncontrado)

      if (pedidoEncontrado.company_id) {
        const { data: empresaData, error: empresaError } = await supabase
          .from('companies')
          .select('id, nome, slug, whatsapp, cor_principal, logo_url')
          .eq('id', pedidoEncontrado.company_id)
          .maybeSingle()

        if (empresaError) {
          setMensagem(`Pedido carregado, mas não consegui buscar a empresa: ${empresaError.message}`)
        } else if (empresaData) {
          setEmpresa(empresaData as Empresa)
        }
      }

      const { data: itensData, error: itensError } = await supabase
        .from('order_items')
        .select('*')
        .eq('order_id', pedidoId)

      if (itensError) {
        setMensagem(
          `Pedido carregado, mas os itens detalhados não foram encontrados: ${itensError.message}`
        )
        setItens([])
        return
      }

      setItens((itensData || []) as ItemPedido[])
    } catch (erro) {
      const textoErro =
        erro instanceof Error
          ? erro.message
          : 'Erro desconhecido ao carregar orçamento.'

      setMensagem(`Erro: ${textoErro}`)
    } finally {
      setCarregando(false)
    }
  }

  async function notificarStatusPedido(novoStatus: string) {
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      const token = sessionData.session?.access_token
      if (!token || !pedido?.id) return

      await fetch('/api/whatsapp/order-status', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          order_id: pedido.id,
          status: novoStatus,
          source: 'pedido',
        }),
      })
    } catch (error) {
      console.error('[OrÃ§aly WhatsApp] Falha ao avisar status:', error)
    }
  }

  async function atualizarStatus(novoStatus: string) {
    if (!pedido) return

    const { error } = await supabase
      .from('orders')
      .update({ status: novoStatus })
      .eq('id', pedido.id)

    if (error) {
      setMensagem(`Erro ao atualizar status: ${error.message}`)
      return
    }

    setPedido({ ...pedido, status: novoStatus })
    await notificarStatusPedido(novoStatus)
    setMensagem('Status atualizado.')
  }

  async function copiarResumo() {
    if (!pedido) return

    const nomeEmpresa = empresa?.nome || 'Empresa'
    const valorTotal = getValorPedido(pedido)

    const resumoItens =
      itens.length > 0
        ? itens
            .map((item) => {
              return `- ${item.nome}: ${item.quantidade || 1} ${item.unidade || ''} | ${formatarDinheiro(Number(item.subtotal || 0))}`
            })
            .join('\n')
        : `- ${pedido.produto}: ${pedido.quantidade || 1} | ${formatarDinheiro(valorTotal)}`

    const texto = `ORÇAMENTO - ${nomeEmpresa}

Cliente: ${pedido.nome}
WhatsApp: ${pedido.telefone}
Data: ${formatarData(pedido.created_at)}

Itens:
${resumoItens}

Total: ${formatarDinheiro(valorTotal)}
${pedido.valor_sinal ? `Sinal: ${formatarDinheiro(Number(pedido.valor_sinal))}` : ''}
Status: ${pedido.status || 'Recebido'}

${pedido.observacoes ? `Observações: ${pedido.observacoes}` : ''}`

    await navigator.clipboard.writeText(texto)
    setMensagem('Resumo copiado.')
  }

  useEffect(() => {
    carregarOrcamento()
  }, [pedidoId])

  const nomeEmpresa = empresa?.nome || 'Orçaly'
  const corPrincipal = empresa?.cor_principal || '#05245c'
  const valorTotal = getValorPedido(pedido)
  const numeroCliente = pedido ? montarWhatsapp(pedido.telefone || '') : ''
  const textoWhatsapp =
    pedido
      ? `Olá, ${pedido.nome}! Segue o resumo do seu orçamento na ${nomeEmpresa}. Total: ${formatarDinheiro(valorTotal)}.`
      : ''
  const linkWhatsapp = numeroCliente
    ? `https://wa.me/${numeroCliente}?text=${encodeURIComponent(textoWhatsapp)}`
    : ''

  if (carregando) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-white px-4">
        <div className="rounded-[2rem] border border-blue-50 bg-white p-8 text-center shadow-xl shadow-blue-950/5">
          <img
            src="/logo-orcaly.png"
            alt="Orçaly"
            className="mx-auto mb-6 h-14 w-auto object-contain"
          />

          <p className="font-bold text-slate-500">Carregando orçamento...</p>

          <p className="mx-auto mt-3 max-w-sm text-sm text-slate-400">
            Se isso ficar preso, normalmente é rota errada, pedido inexistente ou arquivo antigo rodando.
          </p>
        </div>
      </main>
    )
  }

  if (!pedido) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-white px-4">
        <div className="max-w-lg rounded-[2rem] border border-blue-50 bg-white p-8 text-center shadow-xl shadow-blue-950/5">
          <h1 className="text-3xl font-black text-[#071b3a]">
            Orçamento não encontrado
          </h1>

          <p className="mt-3 text-slate-600">
            {mensagem || 'Volte ao painel e tente abrir o pedido novamente.'}
          </p>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <Link
              href="/painel"
              className="rounded-2xl bg-[#05245c] px-6 py-4 font-black text-white"
            >
              Voltar ao painel
            </Link>

            <button
              type="button"
              onClick={carregarOrcamento}
              className="rounded-2xl border border-blue-100 bg-white px-6 py-4 font-black text-[#05245c]"
            >
              Tentar novamente
            </button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-white pb-24 text-slate-950">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute left-[-180px] top-[-180px] h-[420px] w-[420px] rounded-full bg-blue-100 blur-3xl" />
        <div className="absolute right-[-180px] top-[20%] h-[360px] w-[360px] rounded-full bg-cyan-100 blur-3xl" />
        <div className="absolute bottom-[-160px] left-[30%] h-[360px] w-[360px] rounded-full bg-emerald-100 blur-3xl" />
      </div>

      <section className="relative mx-auto w-full max-w-6xl px-4 py-5 sm:px-6">
        <header className="rounded-[2rem] border border-blue-50 bg-white/90 p-5 shadow-xl shadow-blue-950/5 backdrop-blur-xl">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div className="flex items-center gap-4">
              {empresa?.logo_url ? (
                <img
                  src={empresa.logo_url}
                  alt={nomeEmpresa}
                  className="h-16 w-16 rounded-2xl object-cover"
                />
              ) : (
                <img
                  src="/icone-orcaly.png"
                  alt="Orçaly"
                  className="h-16 w-16 rounded-2xl bg-blue-50 object-contain p-2"
                />
              )}

              <div>
                <p
                  className="text-xs font-black uppercase tracking-[0.25em]"
                  style={{ color: corPrincipal }}
                >
                  Orçamento
                </p>

                <h1 className="mt-1 text-3xl font-black text-[#071b3a]">
                  Pedido de {pedido.nome}
                </h1>

                <p className="mt-1 text-sm font-bold text-slate-500">
                  Criado em {formatarData(pedido.created_at)}
                </p>
              </div>
            </div>

            <Link
              href="/painel"
              className="rounded-2xl border border-blue-100 bg-white px-5 py-4 text-center font-black text-[#05245c] transition hover:bg-blue-50"
            >
              Voltar ao painel
            </Link>
          </div>
        </header>

        {mensagem && (
          <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm font-bold text-[#05245c]">
            {mensagem}
          </div>
        )}

        <section className="mt-6 grid gap-6 lg:grid-cols-[1fr_.42fr]">
          <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
            <p className="text-sm font-black uppercase tracking-[0.25em] text-[#05245c]">
              Dados do pedido
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#071b3a]">
              Resumo para orçamento
            </h2>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-3xl bg-blue-50 p-5">
                <p className="text-sm font-bold text-slate-500">Cliente</p>

                <p className="mt-1 text-xl font-black text-[#071b3a]">
                  {pedido.nome}
                </p>

                <p className="mt-1 text-sm font-bold text-slate-500">
                  {pedido.telefone}
                </p>
              </div>

              <div className="rounded-3xl bg-blue-50 p-5">
                <p className="text-sm font-bold text-slate-500">Status</p>

                <select
                  value={pedido.status || 'Recebido'}
                  onChange={(e) => atualizarStatus(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-blue-100 bg-white px-4 py-3 font-black text-[#071b3a] outline-none"
                >
                  {statusOpcoes.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-6 rounded-3xl border border-blue-100 bg-[#f7fbff] p-5">
              <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">
                Itens
              </p>

              {itens.length > 0 ? (
                <div className="mt-4 grid gap-3">
                  {itens.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-2xl bg-white p-4 shadow-sm shadow-blue-950/5"
                    >
                      <div className="flex flex-col justify-between gap-3 sm:flex-row">
                        <div>
                          <p className="font-black text-[#071b3a]">
                            {item.nome}
                          </p>

                          <p className="mt-1 text-sm font-bold text-slate-500">
                            {item.detalhes_calculo ||
                              `${item.quantidade || 1} ${item.unidade || ''}`}
                          </p>
                        </div>

                        <p className="text-xl font-black text-[#05245c]">
                          {formatarDinheiro(Number(item.subtotal || 0))}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-4 rounded-2xl bg-white p-4">
                  <p className="font-black text-[#071b3a]">{pedido.produto}</p>

                  <p className="mt-1 text-sm font-bold text-slate-500">
                    Quantidade: {pedido.quantidade || 1}
                  </p>
                </div>
              )}
            </div>

            {pedido.observacoes && (
              <div className="mt-6 rounded-3xl border border-blue-100 bg-white p-5">
                <p className="text-sm font-black uppercase tracking-[0.2em] text-[#05245c]">
                  Observações
                </p>

                <p className="mt-3 leading-7 text-slate-600">
                  {pedido.observacoes}
                </p>
              </div>
            )}

            {pedido.arquivo_url && (
              <a
                href={pedido.arquivo_url}
                target="_blank"
                className="mt-6 block rounded-2xl border border-blue-100 bg-blue-50 px-5 py-4 text-center font-black text-[#05245c] transition hover:bg-blue-100"
              >
                Abrir arquivo enviado pelo cliente
              </a>
            )}
          </div>

          <aside className="grid gap-6 lg:self-start">
            <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-2xl shadow-blue-950/10">
              <p className="text-sm font-black uppercase tracking-[0.25em] text-[#05245c]">
                Total
              </p>

              <p className="mt-3 text-4xl font-black text-[#071b3a]">
                {formatarDinheiro(valorTotal)}
              </p>

              {pedido.valor_sinal ? (
                <div className="mt-4 rounded-2xl bg-emerald-50 p-4">
                  <p className="text-sm font-bold text-emerald-700">
                    Sinal inicial
                  </p>

                  <p className="mt-1 text-2xl font-black text-emerald-700">
                    {formatarDinheiro(Number(pedido.valor_sinal))}
                  </p>
                </div>
              ) : null}

              <div className="mt-5 grid gap-3">
                <button
                  type="button"
                  onClick={copiarResumo}
                  className="rounded-2xl bg-[#05245c] px-5 py-4 font-black text-white transition hover:bg-[#031a43]"
                >
                  Copiar resumo
                </button>

                {linkWhatsapp && (
                  <a
                    href={linkWhatsapp}
                    target="_blank"
                    className="rounded-2xl bg-emerald-500 px-5 py-4 text-center font-black text-white transition hover:bg-emerald-600"
                  >
                    Enviar no WhatsApp
                  </a>
                )}
              </div>
            </div>

            <div className="rounded-[2rem] border border-blue-50 bg-white p-6 shadow-xl shadow-blue-950/5">
              <p className="text-sm font-black uppercase tracking-[0.25em] text-[#05245c]">
                Pagamento
              </p>

              <div className="mt-4 grid gap-3 text-sm font-bold text-slate-600">
                <p className="rounded-2xl bg-blue-50 p-4">
                  Forma: {pedido.forma_pagamento || 'não definida'}
                </p>

                <p className="rounded-2xl bg-blue-50 p-4">
                  Parcelas: {pedido.parcelas || 'não definido'}
                </p>
              </div>
            </div>
          </aside>
        </section>
      </section>
    </main>
  )
}
