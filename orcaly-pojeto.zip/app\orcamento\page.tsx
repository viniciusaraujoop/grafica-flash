import { redirect } from 'next/navigation'

export default function OrcamentoPage() {
  redirect('/site/grafica-flash')
}
