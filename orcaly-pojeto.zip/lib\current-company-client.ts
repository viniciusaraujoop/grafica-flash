import { supabase } from '@/lib/supabase'

export type CurrentCompanyClientPayload<TCompany = any> = {
  user?: {
    id: string
    email?: string | null
  }
  company: TCompany
  role: 'dono' | 'gerente' | 'atendente' | 'producao' | 'super_admin' | 'funcionario' | null
  assinatura_ativa: boolean
  is_admin_master: boolean
  permissions: {
    is_owner: boolean
    can_manage: boolean
    can_finance: boolean
    can_config: boolean
    can_products: boolean
    can_proposal: boolean
    can_subscription: boolean
    can_production?: boolean
  }
}

export async function getCurrentCompanyClient<TCompany = any>(): Promise<CurrentCompanyClientPayload<TCompany>> {
  const { data: sessionData } = await supabase.auth.getSession()
  const token = sessionData.session?.access_token

  if (!token) {
    throw new Error('Você precisa estar logado.')
  }

  const response = await fetch('/api/company/current', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })

  const payload = await response.json()

  if (!response.ok) {
    throw new Error(payload.error || 'Erro ao carregar empresa atual.')
  }

  if (!payload.company?.id) {
    throw new Error('Empresa não encontrada.')
  }

  return payload as CurrentCompanyClientPayload<TCompany>
}

export async function getAccessTokenClient() {
  const { data: sessionData } = await supabase.auth.getSession()
  const token = sessionData.session?.access_token

  if (!token) {
    throw new Error('Você precisa estar logado.')
  }

  return token
}

export async function getCurrentCompany<TCompany = any>(): Promise<CurrentCompanyClientPayload<TCompany>> {
  return getCurrentCompanyClient<TCompany>()
}
